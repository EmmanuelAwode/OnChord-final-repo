import { useState, useEffect } from 'react';

export interface Reminder {
  id: string;
  type: 'event' | 'album' | 'custom';
  title: string;
  description?: string;
  date: string; // YYYY-MM-DD format
  time?: string; // HH:MM format
  eventId?: string;
  albumId?: string;
  thumbnail?: string;
  location?: string;
  createdAt: string;
  notified?: boolean;
}

const REMINDERS_KEY = 'onchord_reminders';

export function useReminders() {
  const [reminders, setReminders] = useState<Reminder[]>([]);

  // Load reminders from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(REMINDERS_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        setReminders(parsed);
      } catch (error) {
        console.error('Failed to parse reminders:', error);
        setReminders([]);
      }
    }
  }, []);

  // Save reminders to localStorage whenever they change
  useEffect(() => {
    if (reminders.length > 0 || localStorage.getItem(REMINDERS_KEY)) {
      localStorage.setItem(REMINDERS_KEY, JSON.stringify(reminders));
    }
  }, [reminders]);

  const addReminder = (reminder: Omit<Reminder, 'id' | 'createdAt'>) => {
    const newReminder: Reminder = {
      ...reminder,
      id: `reminder_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date().toISOString(),
    };
    setReminders(prev => [...prev, newReminder]);
    return newReminder;
  };

  const removeReminder = (reminderId: string) => {
    setReminders(prev => prev.filter(r => r.id !== reminderId));
  };

  const updateReminder = (reminderId: string, updates: Partial<Reminder>) => {
    setReminders(prev =>
      prev.map(r => (r.id === reminderId ? { ...r, ...updates } : r))
    );
  };

  const getUpcomingReminders = () => {
    const now = new Date();
    const nowStr = now.toISOString().split('T')[0];
    
    return reminders
      .filter(r => r.date >= nowStr)
      .sort((a, b) => {
        const dateCompare = a.date.localeCompare(b.date);
        if (dateCompare !== 0) return dateCompare;
        if (a.time && b.time) return a.time.localeCompare(b.time);
        return 0;
      });
  };

  const getPastReminders = () => {
    const now = new Date();
    const nowStr = now.toISOString().split('T')[0];
    
    return reminders
      .filter(r => r.date < nowStr)
      .sort((a, b) => b.date.localeCompare(a.date));
  };

  const getRemindersForDate = (date: string) => {
    return reminders.filter(r => r.date === date);
  };

  const hasReminderOnDate = (date: string) => {
    return reminders.some(r => r.date === date);
  };

  const getReminderCount = () => {
    return getUpcomingReminders().length;
  };

  return {
    reminders,
    upcomingReminders: getUpcomingReminders(),
    pastReminders: getPastReminders(),
    addReminder,
    removeReminder,
    updateReminder,
    getRemindersForDate,
    hasReminderOnDate,
    reminderCount: getReminderCount(),
  };
}
