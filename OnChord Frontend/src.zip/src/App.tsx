import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AuthPage } from "./components/AuthPage";
import { HomePage } from "./components/HomePage";
import { DiscoverPage } from "./components/DiscoverPage";
import { InsightsPage } from "./components/InsightsPage";
import { ProfilePage } from "./components/ProfilePage";
import { ReviewsPage } from "./components/ReviewsPage";
import { MessagingPage } from "./components/MessagingPage";
import { CollaborativePlaylistPage } from "./components/CollaborativePlaylistPage";
import { CollaborativePlaylistsHub } from "./components/CollaborativePlaylistsHub";
import { CreateReviewPage } from "./components/CreateReviewPage";
import { SettingsPage } from "./components/SettingsPage";
import { EditProfilePage } from "./components/EditProfilePage";
import { NotificationsModal } from "./components/NotificationsModal";
import { RemindersModal } from "./components/RemindersModal";
import { CollectionDetailPage } from "./components/CollectionDetailPage";
import { EventsPage } from "./components/EventsPage";
import { AboutPage } from "./components/AboutPage";
import { PrivacyPage } from "./components/PrivacyPage";
import { TermsPage } from "./components/TermsPage";
import { HelpPage } from "./components/HelpPage";
import { YourSpacePage } from "./components/YourSpacePage";
import { ListsPage } from "./components/ListsPage";
import { LoadingScreen } from "./components/LoadingScreen";
import { OnboardingFlow } from "./components/OnboardingFlow";
import { Navigation } from "./components/Navigation";
import { PreviewProvider } from "./components/SongPreviewPlayer";
import { QuickActionButton } from "./components/QuickActionButton";
import { Footer } from "./components/Footer";
import { AlbumModal } from "./components/AlbumModal";
import { ReviewCreationModal } from "./components/ReviewCreationModal";
import { FindFriendsPage } from "./components/FindFriendsPage";
import { FriendsReviewsPage } from "./components/FriendsReviewsPage";
import { Toaster } from "./components/ui/sonner";
import { albums, currentUser, reviews as initialReviews } from "./lib/mockData";
import { useNavigationHistory } from "./lib/useNavigationHistory";

export default function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [needsOnboarding, setNeedsOnboarding] = useState(false);
  const { currentPage, navigate, goBack, canGoBack } = useNavigationHistory("home");
  const [darkMode, setDarkMode] = useState(true);
  const [accentColor, setAccentColor] = useState("purple");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [albumModalOpen, setAlbumModalOpen] = useState(false);
  const [notificationsModalOpen, setNotificationsModalOpen] = useState(false);
  const [remindersModalOpen, setRemindersModalOpen] = useState(false);
  const [selectedAlbumId, setSelectedAlbumId] = useState<string | undefined>(undefined);
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | undefined>(undefined);
  const [editingReview, setEditingReview] = useState<any>(null);
  const [insightsTab, setInsightsTab] = useState<string>("dashboard");
  const [userData, setUserData] = useState({
    username: "Marcus Williams",
    email: "marcus@onchord.com",
  });
  
  // Review Creation Modal state
  const [reviewModalOpen, setReviewModalOpen] = useState(false);
  const [reviewMediaType, setReviewMediaType] = useState<"album" | "song">("album");
  const [reviewMediaDetails, setReviewMediaDetails] = useState({
    id: "",
    title: "",
    artist: "",
    cover: "",
  });
  
  // Reviews state with localStorage persistence
  const [allReviews, setAllReviews] = useState(() => {
    const saved = localStorage.getItem("onchord_reviews");
    return saved ? JSON.parse(saved) : initialReviews;
  });

  // Save reviews to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("onchord_reviews", JSON.stringify(allReviews));
  }, [allReviews]);

  // Check localStorage on mount to restore session
  useEffect(() => {
    const hasCompletedOnboarding = localStorage.getItem('onchord_onboarding_completed');
    const savedUserData = localStorage.getItem('onchord_user_data');
    const savedAccentColor = localStorage.getItem('onchord_accent_color');

    if (hasCompletedOnboarding === 'true' && savedUserData) {
      // Returning user - restore their data and log them in
      try {
        const parsedUserData = JSON.parse(savedUserData);
        setUserData(parsedUserData);
        if (savedAccentColor) {
          setAccentColor(savedAccentColor);
        }
        setIsLoggedIn(true);
        setNeedsOnboarding(false);
      } catch (error) {
        console.error('Error restoring user data:', error);
        // If data is corrupted, start fresh
        localStorage.removeItem('onchord_onboarding_completed');
        localStorage.removeItem('onchord_user_data');
        localStorage.removeItem('onchord_accent_color');
      }
    }
  }, []);

  // Collaborative playlists state
  const [collaborativePlaylists, setCollaborativePlaylists] = useState([
    {
      id: "collab-1",
      title: "Hip-Hop Heads United",
      description: "A collaborative playlist for real hip-hop lovers",
      cover: albums[0].cover,
      trackCount: 47,
      contributors: [
        {
          id: "user-1",
          name: "Marcus Williams",
          avatar: currentUser.avatar,
        },
        {
          id: "user-2",
          name: "Deja Thompson",
          avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
        },
        {
          id: "user-3",
          name: "Jamal Carter",
          avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
        },
        {
          id: "user-5",
          name: "Andre Jackson",
          avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
        },
      ],
      lastUpdated: "2 hours ago",
      moods: ["Chill", "Study", "Vibes"],
      tracks: [
        {
          id: "t1",
          title: "Sing About Me, I'm Dying of Thirst",
          artist: "Kendrick Lamar",
          addedBy: "Marcus Williams",
          timestamp: "2h ago",
        },
        {
          id: "t2",
          title: "SICKO MODE",
          artist: "Travis Scott",
          addedBy: "Deja Thompson",
          timestamp: "5h ago",
        },
        {
          id: "t3",
          title: "NY State of Mind",
          artist: "Nas",
          addedBy: "Jamal Carter",
          timestamp: "1d ago",
        },
        {
          id: "t4",
          title: "Runaway",
          artist: "Kanye West",
          addedBy: "Andre Jackson",
          timestamp: "2d ago",
        },
        {
          id: "t5",
          title: "C.R.E.A.M.",
          artist: "Wu-Tang Clan",
          addedBy: "Jamal Carter",
          timestamp: "3d ago",
        },
      ],
    },
    {
      id: "collab-2",
      title: "90s Golden Era",
      description: "Timeless classics from the golden age of hip-hop",
      cover: albums[4].cover,
      trackCount: 32,
      contributors: [
        {
          id: "user-1",
          name: "Marcus Williams",
          avatar: currentUser.avatar,
        },
        {
          id: "user-4",
          name: "Tyrone Davis",
          avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
        },
        {
          id: "user-6",
          name: "Maya Robinson",
          avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
        },
      ],
      lastUpdated: "1 day ago",
      moods: ["Classic", "Boom Bap", "Nostalgic"],
      tracks: [
        {
          id: "t6",
          title: "Shook Ones Pt. II",
          artist: "Mobb Deep",
          addedBy: "Marcus Williams",
          timestamp: "1d ago",
        },
        {
          id: "t7",
          title: "The World Is Yours",
          artist: "Nas",
          addedBy: "Tyrone Davis",
          timestamp: "2d ago",
        },
      ],
    },
    {
      id: "collab-3",
      title: "Trap Bangers",
      description: "Modern trap hits that go hard",
      cover: albums[1].cover,
      trackCount: 28,
      contributors: [
        {
          id: "user-1",
          name: "Marcus Williams",
          avatar: currentUser.avatar,
        },
        {
          id: "user-2",
          name: "Deja Thompson",
          avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
        },
      ],
      lastUpdated: "3 days ago",
      moods: ["Hype", "Party", "Workout"],
      tracks: [
        {
          id: "t8",
          title: "GOOSEBUMPS",
          artist: "Travis Scott",
          addedBy: "Deja Thompson",
          timestamp: "3d ago",
        },
      ],
    },
    {
      id: "collab-4",
      title: "Conscious Rap Collection",
      description: "Thought-provoking bars and meaningful messages",
      cover: albums[2].cover,
      trackCount: 41,
      contributors: [
        {
          id: "user-1",
          name: "Marcus Williams",
          avatar: currentUser.avatar,
        },
        {
          id: "user-3",
          name: "Jamal Carter",
          avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
        },
        {
          id: "user-5",
          name: "Andre Jackson",
          avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400",
        },
      ],
      lastUpdated: "5 days ago",
      moods: ["Deep", "Reflective", "Chill"],
      tracks: [
        {
          id: "t9",
          title: "Alright",
          artist: "Kendrick Lamar",
          addedBy: "Marcus Williams",
          timestamp: "5d ago",
        },
      ],
    },
  ]);

  // Simulate initial loading - disabled for faster development
  useEffect(() => {
    // Skip loading screen for now to avoid timeout
    setIsLoading(false);
  }, []);

  // Apply dark mode class to document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  // Close sidebar on ESC key
  useEffect(() => {
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && sidebarOpen) {
        setSidebarOpen(false);
      }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [sidebarOpen]);

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  // Apply accent color to CSS variables
  useEffect(() => {
    const accentColors: Record<string, string> = {
      purple: "#A855F7",
      blue: "#3B82F6",
      pink: "#EC4899",
      green: "#10B981",
      orange: "#F59E0B",
    };
    
    document.documentElement.style.setProperty("--primary", accentColors[accentColor]);
    document.documentElement.style.setProperty("--accent", accentColors[accentColor]);
    document.documentElement.style.setProperty("--ring", accentColors[accentColor]);
  }, [accentColor]);

  const handleLogin = (username: string, email: string) => {
    setUserData({ username, email });
    
    // Check if this user has already completed onboarding
    const hasCompletedOnboarding = localStorage.getItem('onchord_onboarding_completed');
    const savedUserData = localStorage.getItem('onchord_user_data');
    
    if (hasCompletedOnboarding === 'true' && savedUserData) {
      // Returning user - skip onboarding, go directly to home
      try {
        const parsedUserData = JSON.parse(savedUserData);
        setUserData(parsedUserData);
        const savedAccentColor = localStorage.getItem('onchord_accent_color');
        if (savedAccentColor) {
          setAccentColor(savedAccentColor);
        }
        setIsLoggedIn(true);
        setNeedsOnboarding(false);
      } catch (error) {
        console.error('Error restoring user data:', error);
        // If data is corrupted, show onboarding for fresh start
        setNeedsOnboarding(true);
      }
    } else {
      // First-time user - show onboarding
      setNeedsOnboarding(true);
    }
  };

  const handleOnboardingComplete = (data: { displayName: string; accentColor: string }) => {
    setUserData(prev => ({ ...prev, username: data.displayName }));
    setAccentColor(data.accentColor);
    setNeedsOnboarding(false);
    setIsLoggedIn(true);
    // Save user data to localStorage
    localStorage.setItem('onchord_onboarding_completed', 'true');
    localStorage.setItem('onchord_user_data', JSON.stringify({ username: data.displayName, email: userData.email }));
    localStorage.setItem('onchord_accent_color', data.accentColor);
  };

  const handleOpenAlbumModal = (albumId?: string) => {
    setSelectedAlbumId(albumId);
    setAlbumModalOpen(true);
  };

  const handleCloseAlbumModal = () => {
    setAlbumModalOpen(false);
    setSelectedAlbumId(undefined);
  };

  const handleOpenPlaylist = (playlistId: string) => {
    setSelectedPlaylistId(playlistId);
    navigate("playlist-detail");
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    navigate("home");
    // Clear user data from localStorage
    localStorage.removeItem('onchord_onboarding_completed');
    localStorage.removeItem('onchord_user_data');
    localStorage.removeItem('onchord_accent_color');
  };

  const handleQuickAction = (action: string) => {
    switch (action) {
      case "review":
        navigate("review");
        break;
      case "collab":
        navigate("playlist");
        break;
      case "list":
        navigate("your-space-lists");
        break;
      case "event":
        navigate("events");
        break;
      case "connect":
        navigate("find-friends");
        break;
      default:
        break;
    }
  };

  const handleOpenReviewModal = (mediaType: "album" | "song", mediaId: string, mediaTitle: string, mediaArtist: string, mediaCover: string) => {
    setReviewMediaType(mediaType);
    setReviewMediaDetails({
      id: mediaId,
      title: mediaTitle,
      artist: mediaArtist,
      cover: mediaCover,
    });
    setReviewModalOpen(true);
    // Close the album modal if it's open
    setAlbumModalOpen(false);
  };

  // Navigation handler with options support
  const handleNavigate = (page: string, options?: { insightsTab?: string }) => {
    if (options?.insightsTab) {
      setInsightsTab(options.insightsTab);
    }
    navigate(page);
  };

  const handleSubmitReview = (reviewData: {
    id?: string;
    rating: number;
    content: string;
    mood?: string;
    listeningContext?: string;
    favoriteTrack?: string;
    visibility: "public" | "friends" | "private";
  }) => {
    if (reviewData.id) {
      // Edit existing review
      setAllReviews((prev: any[]) => {
        const updated = prev.map(r => 
          r.id === reviewData.id 
            ? { 
                ...r, 
                rating: reviewData.rating,
                content: reviewData.content,
                mood: reviewData.mood || "",
                listeningContext: reviewData.listeningContext || "",
                favoriteTrack: reviewData.favoriteTrack || "",
                visibility: reviewData.visibility,
                isEdited: true,
                editedAt: new Date().toISOString(),
              }
            : r
        );
        // Save to localStorage for persistence
        try {
          localStorage.setItem('onchord_user_reviews', JSON.stringify(updated.filter(r => r.userId === "user-1")));
        } catch (error) {
          console.error('Failed to save reviews to localStorage:', error);
        }
        return updated;
      });
      
      // Show success toast
      import("sonner@2.0.3").then(({ toast }) => {
        toast.success("Review updated successfully!");
      });
      
      // Close edit mode
      setEditingReview(null);
    } else {
      // Create new review object
      const newReview = {
        id: `r${Date.now()}`,
        userId: "user-1",
        userName: userData.username || currentUser.name,
        userAvatar: currentUser.avatar,
        albumId: reviewMediaDetails.id,
        albumTitle: reviewMediaDetails.title,
        albumArtist: reviewMediaDetails.artist,
        albumCover: reviewMediaDetails.cover,
        rating: reviewData.rating,
        type: reviewMediaType,
        content: reviewData.content,
        timestamp: "Just now",
        date: new Date().toISOString().split('T')[0],
        likes: 0,
        comments: 0,
        tags: [],
        mood: reviewData.mood || "",
        listeningContext: reviewData.listeningContext || "",
        favoriteTrack: reviewData.favoriteTrack || "",
        visibility: reviewData.visibility,
      };

      // Add review to the beginning of the array
      setAllReviews((prev: any[]) => {
        const updated = [newReview, ...prev];
        // Save to localStorage for persistence
        try {
          localStorage.setItem('onchord_user_reviews', JSON.stringify(updated.filter(r => r.userId === "user-1")));
        } catch (error) {
          console.error('Failed to save reviews to localStorage:', error);
        }
        return updated;
      });
      
      // Show success toast
      import("sonner@2.0.3").then(({ toast }) => {
        toast.success(`Review for "${reviewMediaDetails.title}" submitted successfully!`);
      });
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <HomePage onNavigate={navigate} username={userData.username} onOpenAlbum={handleOpenAlbumModal} onEditReview={setEditingReview} reviews={allReviews} />;
      case "discover":
        return <DiscoverPage onNavigate={handleNavigate} onOpenAlbum={handleOpenAlbumModal} onOpenReviewModal={handleOpenReviewModal} />;
      case "search":
        // Redirect to home page
        navigate("home");
        return <HomePage onNavigate={navigate} username={userData.username} onOpenAlbum={handleOpenAlbumModal} />;
      case "events":
        return <EventsPage onNavigate={navigate} onBack={goBack} canGoBack={canGoBack} />;
      case "insights":
        return <InsightsPage onNavigate={navigate} defaultTab={insightsTab} />;
      case "reviews":
        return <ReviewsPage onNavigate={navigate} onOpenAlbum={handleOpenAlbumModal} onEditReview={setEditingReview} />;
      case "your-space":
        return (
          <YourSpacePage 
            onNavigate={navigate} 
            onOpenAlbum={handleOpenAlbumModal}
            darkMode={darkMode}
            onDarkModeChange={setDarkMode}
            accentColor={accentColor}
            onAccentColorChange={setAccentColor}
            onLogout={handleLogout}
            onEditReview={setEditingReview}
          />
        );
      case "your-space-lists":
        return (
          <YourSpacePage 
            onNavigate={navigate} 
            onOpenAlbum={handleOpenAlbumModal}
            darkMode={darkMode}
            onDarkModeChange={setDarkMode}
            accentColor={accentColor}
            onAccentColorChange={setAccentColor}
            initialTab="lists"
            onLogout={handleLogout}
            onEditReview={setEditingReview}
          />
        );
      case "your-space-followers":
        return (
          <YourSpacePage 
            onNavigate={navigate} 
            onOpenAlbum={handleOpenAlbumModal}
            darkMode={darkMode}
            onDarkModeChange={setDarkMode}
            accentColor={accentColor}
            onAccentColorChange={setAccentColor}
            initialTab="followers"
            onLogout={handleLogout}
            onEditReview={setEditingReview}
          />
        );
      case "lists":
        return (
          <ListsPage
            onNavigate={navigate}
            onOpenAlbum={handleOpenAlbumModal}
          />
        );
      case "profile":
        return <ProfilePage username={userData.username} onNavigate={navigate} onOpenAlbum={handleOpenAlbumModal} onBack={goBack} canGoBack={canGoBack} />;
      case "edit-profile":
        return <EditProfilePage onNavigate={navigate} onBack={goBack} canGoBack={canGoBack} />;
      case "feed":
        // Redirect to home page
        navigate("home");
        return <HomePage onNavigate={navigate} username={userData.username} onOpenAlbum={handleOpenAlbumModal} />;
      case "messages":
        return <MessagingPage onBack={goBack} canGoBack={canGoBack} />;
      case "playlist":
        return (
          <CollaborativePlaylistsHub 
            onNavigate={navigate} 
            onOpenPlaylist={handleOpenPlaylist}
            playlists={collaborativePlaylists}
            setPlaylists={setCollaborativePlaylists}
            onBack={goBack}
            canGoBack={canGoBack}
          />
        );
      case "playlist-detail":
        return (
          <CollaborativePlaylistPage 
            onNavigate={navigate} 
            playlistId={selectedPlaylistId}
            playlists={collaborativePlaylists}
            setPlaylists={setCollaborativePlaylists}
            onBack={goBack}
            canGoBack={canGoBack}
          />
        );
      case "review":
        return <CreateReviewPage onNavigate={navigate} onBack={goBack} editingReview={editingReview} onClearEdit={() => setEditingReview(null)} />;
      case "settings":
        return (
          <SettingsPage 
            darkMode={darkMode}
            onDarkModeChange={setDarkMode}
            accentColor={accentColor}
            onAccentColorChange={setAccentColor}
            onLogout={handleLogout}
            onBack={goBack}
            canGoBack={canGoBack}
          />
        );
      case "about":
        return <AboutPage onNavigate={navigate} onBack={goBack} canGoBack={canGoBack} />;
      case "privacy":
        return <PrivacyPage onNavigate={navigate} onBack={goBack} canGoBack={canGoBack} />;
      case "terms":
        return <TermsPage onNavigate={navigate} onBack={goBack} canGoBack={canGoBack} />;
      case "help":
        return <HelpPage onNavigate={navigate} onBack={goBack} canGoBack={canGoBack} />;
      case "find-friends":
        return <FindFriendsPage onNavigate={navigate} onBack={goBack} canGoBack={canGoBack} />;
      case "friends-reviews":
        return <FriendsReviewsPage onNavigate={navigate} onOpenAlbum={handleOpenAlbumModal} onBack={goBack} canGoBack={canGoBack} />;
      default:
        // Check if it's a settings page with a specific tab
        if (currentPage.startsWith("settings-")) {
          const settingsTab = currentPage.replace("settings-", "");
          return (
            <SettingsPage 
              darkMode={darkMode}
              onDarkModeChange={setDarkMode}
              accentColor={accentColor}
              onAccentColorChange={setAccentColor}
              onLogout={handleLogout}
              onBack={goBack}
              canGoBack={canGoBack}
              initialTab={settingsTab}
            />
          );
        }
        // Check if it's a collection detail page
        if (currentPage.startsWith("collection-")) {
          const listId = currentPage.replace("collection-", "");
          return (
            <CollectionDetailPage 
              listId={listId}
              onNavigate={navigate}
              onOpenAlbum={handleOpenAlbumModal}
              onBack={goBack}
              canGoBack={canGoBack}
            />
          );
        }
        return <HomePage onNavigate={navigate} username={userData.username} onOpenAlbum={handleOpenAlbumModal} />;
    }
  };

  // Show loading screen
  if (isLoading) {
    return <LoadingScreen />;
  }

  // Show auth page if not logged in
  if (!isLoggedIn && !needsOnboarding) {
    return <AuthPage onLogin={handleLogin} />;
  }

  // Show onboarding flow for new users
  if (needsOnboarding) {
    return <OnboardingFlow onComplete={handleOnboardingComplete} />;
  }

  return (
    <PreviewProvider>
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Music-themed background elements */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {/* Gradient orbs */}
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse-slow"></div>
        <div className="absolute top-1/3 -left-40 w-96 h-96 bg-secondary/10 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-20 right-1/4 w-80 h-80 bg-accent/10 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '2s' }}></div>
        {/* Waveform pattern */}
        <div className="absolute inset-0 pattern-waveform opacity-30"></div>
      </div>
      
      <Navigation 
        currentPage={currentPage} 
        onNavigate={(page) => {
          navigate(page);
          setSidebarOpen(false); // Close sidebar on navigation
        }}
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        username={userData.username}
        email={userData.email}
        onOpenNotifications={() => setNotificationsModalOpen(true)}
        onOpenReminders={() => setRemindersModalOpen(true)}
        onLogout={handleLogout}
      />
      
      {/* Main Content with Page Transitions */}
      <main className={`transition-all duration-300 ${sidebarOpen ? 'md:ml-64' : 'md:ml-0'} p-4 md:pl-24 md:pr-8 md:pt-8 pb-24 md:pb-8 relative z-10`}>
        {/* Toggle Button - Fixed position - Only show when closed on desktop */}
        <AnimatePresence>
          {!sidebarOpen && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.2 }}
              onClick={() => setSidebarOpen(true)}
              className="hidden md:flex fixed top-6 left-6 z-40 p-3 rounded-xl bg-gradient-to-br from-card to-card/80 backdrop-blur-xl border-2 border-primary/30 shadow-md hover:shadow-lg hover:border-primary hover:scale-110 transition-all items-center justify-center group"
              aria-label="Open menu"
            >
              <svg
                className="w-6 h-6 text-primary group-hover:text-primary transition-colors drop-shadow-lg"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M4 6h16M4 12h16M4 18h16"
                />
              </svg>
            </motion.button>
          )}
        </AnimatePresence>

        <motion.div 
          className="max-w-6xl mx-auto"
          animate={{ 
            paddingLeft: sidebarOpen ? '1rem' : '0'
          }}
          transition={{ duration: 0.3 }}
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPage}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {renderPage()}
            </motion.div>
          </AnimatePresence>

          {/* Footer */}
          <Footer onNavigate={navigate} />
        </motion.div>
      </main>

      {/* Quick Action Button */}
      <QuickActionButton onAction={handleQuickAction} />

      {/* Album Modal */}
      <AlbumModal 
        isOpen={albumModalOpen} 
        onClose={handleCloseAlbumModal}
        albumId={selectedAlbumId}
        onOpenReviewModal={handleOpenReviewModal}
        reviews={allReviews}
      />

      {/* Review Creation Modal */}
      <ReviewCreationModal
        isOpen={reviewModalOpen}
        onClose={() => setReviewModalOpen(false)}
        onSubmit={handleSubmitReview}
        mediaType={reviewMediaType}
        mediaTitle={reviewMediaDetails.title}
        mediaArtist={reviewMediaDetails.artist}
        mediaCover={reviewMediaDetails.cover}
      />

      {/* Edit Review Modal */}
      {editingReview && (
        <ReviewCreationModal
          isOpen={!!editingReview}
          onClose={() => setEditingReview(null)}
          onSubmit={handleSubmitReview}
          mediaType={editingReview.type || "album"}
          mediaTitle={editingReview.albumTitle}
          mediaArtist={editingReview.albumArtist}
          mediaCover={editingReview.albumCover}
          editMode={true}
          existingReview={{
            id: editingReview.id,
            rating: editingReview.rating,
            content: editingReview.content,
            mood: editingReview.mood,
            listeningContext: editingReview.listeningContext,
            favoriteTrack: editingReview.favoriteTrack,
            visibility: editingReview.visibility || "public",
          }}
        />
      )}

      {/* Notifications Modal */}
      <NotificationsModal 
        isOpen={notificationsModalOpen}
        onClose={() => setNotificationsModalOpen(false)}
        onNavigate={(page) => {
          navigate(page);
          setNotificationsModalOpen(false);
        }}
      />

      {/* Reminders Modal */}
      <RemindersModal 
        isOpen={remindersModalOpen}
        onClose={() => setRemindersModalOpen(false)}
      />

      {/* Toast Notifications */}
      <Toaster 
        position="top-right"
        theme={darkMode ? "dark" : "light"}
        richColors
      />
    </div>
    </PreviewProvider>
  );
}