import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Avatar } from "./ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { MusicEmbed } from "./MusicEmbed";
import { Star, Heart, MessageCircle, Share2, Plus, X, ChevronDown, ChevronUp } from "lucide-react";
import { albums, reviews } from "../lib/mockData";
import { useFavourites } from "../lib/useFavourites";
import { toast } from "sonner";
import { Badge } from "./ui/badge";
import { useState } from "react";
import { ExpandableReviewCard } from "./ExpandableReviewCard";

interface AlbumModalProps {
  isOpen: boolean;
  onClose: () => void;
  albumId?: string;
  onOpenReviewModal?: (mediaType: "album" | "song", mediaId: string, mediaTitle: string, mediaArtist: string, mediaCover: string) => void;
  reviews?: any[];
}

export function AlbumModal({ isOpen, onClose, albumId, onOpenReviewModal, reviews: propReviews }: AlbumModalProps) {
  // Get album by ID or use first album as fallback
  const album = albumId 
    ? albums.find(a => a.id === albumId) || albums[0]
    : albums[0];
  
  // Use provided reviews or fall back to mock reviews
  const allReviews = propReviews || reviews;
  const albumReviews = allReviews.filter((r) => r.albumId === album.id);

  const { isAlbumFavourite, toggleAlbum } = useFavourites();
  const isFavourite = isAlbumFavourite(album.id);

  const handleToggleFavourite = () => {
    const added = toggleAlbum({
      id: album.id,
      title: album.title,
      artist: album.artist,
      cover: album.cover,
      releaseDate: album.year,
      trackCount: typeof album.tracks === 'number' ? album.tracks : undefined,
    });

    if (added) {
      toast.success(`Added "${album.title}" to favourites`);
    } else {
      toast.success(`Removed "${album.title}" from favourites`);
    }
  };

  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-[95vw] max-w-[1600px] max-h-[90vh] overflow-y-auto bg-card border-border p-0">
        <DialogHeader className="sr-only">
          <DialogTitle>{album.title}</DialogTitle>
          <DialogDescription>
            Album details for {album.title} by {album.artist}
          </DialogDescription>
        </DialogHeader>

        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-50 rounded-full p-2 bg-background/80 backdrop-blur-sm hover:bg-background transition-colors"
          aria-label="Close"
        >
          <X className="w-4 h-4 text-foreground" />
        </button>

        <div className="p-4 md:p-8 space-y-6">
          {/* Album Header */}
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-6 md:gap-8">
              {/* Album Cover */}
              <img
                src={album.cover}
                alt={album.title}
                className="w-full md:w-56 lg:w-64 aspect-square object-cover rounded-xl shadow-2xl flex-shrink-0"
              />

              {/* Album Info */}
              <div className="flex-1 space-y-4">
                <div>
                  <h1 className="text-3xl md:text-4xl text-foreground mb-2">{album.title}</h1>
                  <p className="text-lg md:text-xl text-muted-foreground">{album.artist}</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {album.year} · {album.genre}
                  </p>
                </div>

                {/* Rating */}
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 bg-primary/20 px-4 py-2 rounded-lg">
                    <Star className="w-6 h-6 text-primary fill-primary" />
                    <span className="text-2xl text-foreground">{album.rating}</span>
                    <span className="text-muted-foreground">/5</span>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Based on {albumReviews.length} reviews
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3 pt-4">
                  <Button 
                    className="bg-primary hover:bg-primary/90 text-primary-foreground"
                    onClick={() => {
                      if (onOpenReviewModal) {
                        onOpenReviewModal("album", album.id, album.title, album.artist, album.cover);
                      }
                    }}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Log / Review This
                  </Button>
                  <Button
                    variant="outline"
                    className="border-border"
                    onClick={handleToggleFavourite}
                  >
                    <Heart className="w-4 h-4 mr-2" />
                    {isFavourite ? "Remove from" : "Add to"} Favorites
                  </Button>
                  <Button variant="outline" className="border-border">
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                </div>

                {/* Stats */}
                <div className="flex gap-6 pt-4 border-t border-border">
                  <div>
                    <p className="text-foreground">1.2K</p>
                    <p className="text-sm text-muted-foreground">Listeners</p>
                  </div>
                  <div>
                    <p className="text-foreground">342</p>
                    <p className="text-sm text-muted-foreground">Reviews</p>
                  </div>
                  <div>
                    <p className="text-foreground">56</p>
                    <p className="text-sm text-muted-foreground">Lists</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Spotify/Apple Music Embeds */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <MusicEmbed
              type="spotify"
              url="https://open.spotify.com/album/79dL7FLiJFOO0EoehUHQBv"
              embedType="album"
            />
            <MusicEmbed
              type="apple"
              url="https://music.apple.com/album/currents/1440873968"
              title="Currents"
              artist="Tame Impala"
            />
          </div>

          {/* Tabs */}
          <Tabs defaultValue="reviews" className="w-full">
            <TabsList className="bg-card border border-border w-full md:w-auto">
              <TabsTrigger
                value="reviews"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                Reviews
              </TabsTrigger>
              <TabsTrigger
                value="ratings"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                Ratings
              </TabsTrigger>
              <TabsTrigger
                value="lists"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                Related Lists
              </TabsTrigger>
            </TabsList>

            {/* Reviews Tab */}
            <TabsContent value="reviews" className="space-y-4 mt-6">
              {albumReviews.length > 0 ? (
                albumReviews.map((review) => (
                  <ExpandableReviewCard key={review.id} review={review} />
                ))
              ) : (
                <Card className="p-8 bg-card border-border border-dashed">
                  <div className="text-center space-y-3">
                    <MessageCircle className="w-12 h-12 text-muted-foreground mx-auto opacity-50" />
                    <p className="text-muted-foreground">No reviews yet for this album</p>
                    <p className="text-sm text-muted-foreground">Be the first to share your thoughts!</p>
                    <Button 
                      className="mt-4 bg-primary hover:bg-primary/90 text-primary-foreground"
                      onClick={() => {
                        if (onOpenReviewModal) {
                          onOpenReviewModal("album", album.id, album.title, album.artist, album.cover);
                        }
                      }}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Write a Review
                    </Button>
                  </div>
                </Card>
              )}
            </TabsContent>

            {/* Ratings Tab */}
            <TabsContent value="ratings" className="mt-6">
              <Card className="p-6 bg-card border-border">
                <h3 className="text-foreground mb-4">Rating Distribution</h3>
                <div className="space-y-3">
                  {[5, 4, 3, 2, 1].map((stars) => (
                    <div key={stars} className="flex items-center gap-4">
                      <div className="flex items-center gap-1 w-16">
                        <Star className="w-4 h-4 text-primary fill-primary" />
                        <span className="text-foreground">{stars}</span>
                      </div>
                      <div className="flex-1 bg-muted rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full"
                          style={{ width: `${Math.random() * 100}%` }}
                        />
                      </div>
                      <span className="text-muted-foreground text-sm w-12 text-right">
                        {Math.floor(Math.random() * 200)}
                      </span>
                    </div>
                  ))}
                </div>
              </Card>
            </TabsContent>

            {/* Lists Tab */}
            <TabsContent value="lists" className="mt-6">
              <Card className="p-6 bg-card border-border">
                <p className="text-muted-foreground text-center py-8">
                  This album appears in 56 user lists
                </p>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}