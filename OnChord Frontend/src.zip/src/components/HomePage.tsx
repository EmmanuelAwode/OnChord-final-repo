import { Heart, MessageCircle, Share2, TrendingUp, Clock, Calendar, Star, Music2, Radio, Headphones, Users, Info, Edit3, Search, Plus, Sparkles, Flame, MapPin, Play, Disc3, UserPlus, Trash2 } from "lucide-react";
import { EditedIndicator } from "./EditedIndicator";
import { ReviewDetailModal } from "./ReviewDetailModal";
import { EmptyState } from "./EmptyState";
import { ExpandableReviewCard } from "./ExpandableReviewCard";
import { CommentsModal } from "./CommentsModal";
import { useState } from "react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Avatar } from "./ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { PreviewButton } from "./SongPreviewPlayer";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "./ui/alert-dialog";
import { 
  extendedReviews, 
  newReleases, 
  upcomingEvents, 
  membersActivity,
  personalStats,
  myLists,
  currentUser,
  albums,
  tasteMatches
} from "../lib/mockData";
import { useFollowing, useLikes, useReviews } from "../lib/useUserInteractions";
import { toast } from "sonner@2.0.3";

// Simple Event Modal stub
function EventModal({ event, isOpen, onClose }: { event: any; isOpen: boolean; onClose: () => void }) {
  if (!isOpen || !event) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60" onClick={onClose}>
      <Card className="max-w-md w-full p-6" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-xl text-foreground mb-2">{event.artistName}</h3>
        <p className="text-muted-foreground mb-2">{event.venue}</p>
        <p className="text-muted-foreground mb-4">{event.city} • {event.date}</p>
        <Button onClick={onClose}>Close</Button>
      </Card>
    </div>
  );
}

interface HomePageProps {
  onNavigate?: (page: string) => void;
  username?: string;
  onOpenAlbum?: (albumId?: string) => void;
  onEditReview?: (review: any) => void;
  reviews?: any[];
  initialTab?: string;
}

export function HomePage({ onNavigate, username, onOpenAlbum, onEditReview, reviews: propReviews, initialTab }: HomePageProps = {}) {
  const { userReviews: savedReviews, deleteReview } = useReviews();
  const [searchQuery, setSearchQuery] = useState("");
  // Restore tab from localStorage or use initialTab or default to "for-you"
  const [activeTab, setActiveTab] = useState(() => {
    if (initialTab) return initialTab;
    const savedTab = localStorage.getItem("onchord_home_tab");
    return savedTab || "for-you";
  });
  const [likedReviews, setLikedReviews] = useState<string[]>([]);
  const [commentsModalOpen, setCommentsModalOpen] = useState(false);
  const [selectedReview, setSelectedReview] = useState<any>(null);
  const [eventModalOpen, setEventModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [reviewDetailModalOpen, setReviewDetailModalOpen] = useState(false);
  const [selectedReviewDetail, setSelectedReviewDetail] = useState<any>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [reviewToDelete, setReviewToDelete] = useState<any>(null);
  const displayName = username || currentUser.name.split(' ')[0];
  
  // Combine prop reviews with extended reviews, prop reviews first (they're newest)
  const allReviewsData = propReviews ? [...propReviews, ...extendedReviews] : extendedReviews;
  
  // Combine user reviews with mock reviews for the current user
  const mockUserReviews = allReviewsData.filter((r) => r.userId === currentUser.id);
  const allUserReviews = [...mockUserReviews, ...savedReviews];
  const { toggleFollow, isFollowing } = useFollowing();
  const { toggleLike: toggleLikePersist, isLiked } = useLikes();

  // Separate my reviews and friends' reviews
  const myReviews = allUserReviews;
  const friendsReviews = allReviewsData.filter(r => r.userId !== currentUser.id);

  const toggleLike = (reviewId: string) => {
    setLikedReviews(prev => 
      prev.includes(reviewId) 
        ? prev.filter(id => id !== reviewId)
        : [...prev, reviewId]
    );
    toggleLikePersist(reviewId);
  };

  const handleReviewClick = (review: any) => {
    setSelectedReviewDetail(review);
    setReviewDetailModalOpen(true);
  };

  const handleFollowToggle = (userId: string, userName: string) => {
    toggleFollow(userId);
    if (isFollowing(userId)) {
      toast.success(`Unfollowed ${userName}`);
    } else {
      toast.success(`Following ${userName}`);
    }
  };

  const handleDeleteClick = (e: React.MouseEvent, review: any) => {
    e.stopPropagation();
    setReviewToDelete(review);
    setDeleteDialogOpen(true);
  };

  const handleConfirmDelete = () => {
    if (reviewToDelete) {
      deleteReview(reviewToDelete.id);
      toast.success("Review deleted successfully");
      setDeleteDialogOpen(false);
      setReviewToDelete(null);
    }
  };

  const handleShare = (review: any) => {
    toast.success("Link copied to clipboard!", {
      description: `Share your review of ${review.albumTitle}`
    });
  };

  // Get greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };

  // Filter search results
  const filteredAlbums = albums.filter(
    (album) =>
      album.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      album.artist.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredUsers = tasteMatches.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredReviews = allReviewsData.filter(
    (review) =>
      review.albumTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      review.albumArtist.toLowerCase().includes(searchQuery.toLowerCase()) ||
      review.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const hasSearchResults = searchQuery.trim() && (filteredAlbums.length > 0 || filteredUsers.length > 0 || filteredReviews.length > 0);

  return (
    <div className="min-h-screen relative pb-12">
      {/* Hero Header Section */}
      <div className="mb-6 space-y-4 animate-fade-in">
        {/* Greeting & Stats */}
        <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
          <div>
            <h1 className="text-3xl md:text-4xl text-foreground mb-1">
              {getGreeting()}, {displayName}! 👋
            </h1>
            <p className="text-muted-foreground">Your musical journey continues</p>
          </div>
          
          {/* Personal Stats Cards */}
          <div className="grid grid-cols-3 gap-2 md:gap-3 w-full lg:w-auto">
            <Card 
              onClick={() => onNavigate?.('your-space-reviews')}
              className="p-3 md:p-4 text-center border-border hover:border-primary hover:shadow-glow-primary transition-all cursor-pointer group shadow-soft hover:shadow-medium"
            >
              <div className="flex flex-col items-center gap-1">
                <div className="flex items-center justify-center w-8 h-8 md:w-10 md:h-10 rounded-full bg-primary/10 mb-1 group-hover:scale-110 group-hover:bg-primary/20 transition-all">
                  <Star className="w-4 h-4 md:w-5 md:h-5 text-primary" />
                </div>
                <p className="text-lg md:text-2xl text-primary group-hover:scale-110 transition-transform">{personalStats.reviewsCount}</p>
                <p className="text-[10px] md:text-xs text-muted-foreground">Reviews</p>
              </div>
            </Card>
            <Card 
              onClick={() => onNavigate?.('your-space-lists')}
              className="p-3 md:p-4 text-center border-border hover:border-secondary hover:shadow-glow-secondary transition-all cursor-pointer group shadow-soft hover:shadow-medium"
            >
              <div className="flex flex-col items-center gap-1">
                <div className="flex items-center justify-center w-8 h-8 md:w-10 md:h-10 rounded-full bg-secondary/10 mb-1 group-hover:scale-110 group-hover:bg-secondary/20 transition-all">
                  <Music2 className="w-4 h-4 md:w-5 md:h-5 text-secondary" />
                </div>
                <p className="text-lg md:text-2xl text-secondary group-hover:scale-110 transition-transform">{personalStats.listsCount}</p>
                <p className="text-[10px] md:text-xs text-muted-foreground">Lists</p>
              </div>
            </Card>
            <Card 
              onClick={() => onNavigate?.('your-space-followers')}
              className="p-3 md:p-4 text-center border-border hover:border-chart-3 transition-all cursor-pointer group shadow-soft hover:shadow-medium"
            >
              <div className="flex flex-col items-center gap-1">
                <div className="flex items-center justify-center w-8 h-8 md:w-10 md:h-10 rounded-full bg-chart-3/10 mb-1 group-hover:scale-110 group-hover:bg-chart-3/20 transition-all">
                  <Users className="w-4 h-4 md:w-5 md:h-5 text-chart-3" />
                </div>
                <p className="text-lg md:text-2xl text-chart-3 group-hover:scale-110 transition-transform">{personalStats.followersCount}</p>
                <p className="text-[10px] md:text-xs text-muted-foreground">Followers</p>
              </div>
            </Card>
          </div>
        </div>

        {/* Search Bar */}
        <Card className="shadow-soft">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search albums, artists, users, or reviews..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (e.target.value.trim()) {
                  setActiveTab("search");
                  localStorage.setItem("onchord_home_tab", "search");
                }
              }}
              className="pl-12 pr-4 py-6 border-0 bg-transparent text-foreground placeholder:text-muted-foreground focus-visible:ring-0"
            />
          </div>
        </Card>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={(tab) => {
        setActiveTab(tab);
        localStorage.setItem("onchord_home_tab", tab);
      }} className="space-y-6">
        <TabsList className="bg-card border border-border w-full grid grid-cols-3 h-auto p-1">
          <TabsTrigger 
            value="for-you" 
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground py-3"
          >
            <Star className="w-4 h-4 mr-2" />
            <span className="hidden sm:inline">For You</span>
            <span className="sm:hidden">You</span>
          </TabsTrigger>
          <TabsTrigger 
            value="community" 
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground py-3"
          >
            <Users className="w-4 h-4 mr-2" />
            <span className="hidden sm:inline">Community</span>
            <span className="sm:hidden">Feed</span>
          </TabsTrigger>
          <TabsTrigger 
            value="discover" 
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground py-3"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Discover
          </TabsTrigger>
        </TabsList>

        {/* For You Tab */}
        <TabsContent value="for-you" className="space-y-6">
          {/* My Recent Reviews */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl md:text-2xl text-foreground">Your Recent Reviews</h2>
              <Button 
                onClick={() => onNavigate?.("review")}
                size="sm"
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <Plus className="w-4 h-4 mr-2" />
                Write
              </Button>
            </div>

            <div className="grid gap-4">
              {myReviews.slice(0, 3).map((review, index) => (
                <Card 
                  key={`my-review-${review.id}-${index}`}
                  className="p-4 md:p-6 bg-card border-border hover:border-primary/50 transition-all shadow-soft hover:shadow-medium"
                >
                  <div className="flex gap-4">
                    <div 
                      className="flex-shrink-0 cursor-pointer"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenAlbum?.();
                      }}
                    >
                      <img
                        src={review.albumCover}
                        alt={review.albumTitle}
                        className="w-20 h-20 md:w-24 md:h-24 rounded-lg object-cover hover:scale-105 transition-transform"
                      />
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-4 mb-2">
                        <div className="flex-1 min-w-0">
                          <h3 className="text-foreground mb-1 truncate">{review.albumTitle}</h3>
                          <p className="text-sm text-muted-foreground truncate">{review.albumArtist}</p>
                        </div>
                        <div className="flex items-center gap-1 bg-primary/20 px-3 py-1 rounded-full">
                          <Star className="w-4 h-4 text-primary fill-primary" />
                          <span className="text-foreground">{review.rating}</span>
                        </div>
                      </div>
                      
                      {review.tags && (
                        <div className="flex flex-wrap gap-2 mb-2">
                          {review.tags.map((tag) => (
                            <Badge key={tag} className="bg-primary/10 text-primary border-0 text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}

                      <p className="text-foreground mb-3 text-sm line-clamp-2">{review.content}</p>
                      
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleLike(review.id);
                          }}
                          className={`flex items-center gap-1 transition ${
                            likedReviews.includes(review.id) ? "text-secondary" : "hover:text-secondary"
                          }`}
                        >
                          <Heart className={`w-4 h-4 ${likedReviews.includes(review.id) ? "fill-secondary" : ""}`} />
                          {review.likes + (likedReviews.includes(review.id) ? 1 : 0)}
                        </button>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedReview(review);
                            setCommentsModalOpen(true);
                          }}
                          className="flex items-center gap-1 hover:text-primary transition"
                        >
                          <MessageCircle className="w-4 h-4" />
                          {review.comments}
                        </button>
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            handleShare(review);
                          }}
                          className="flex items-center gap-1 hover:text-foreground transition"
                        >
                          <Share2 className="w-4 h-4" />
                        </button>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex gap-2 mt-3">
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            onEditReview?.(review);
                          }}
                          variant="outline"
                          size="sm"
                          className="flex-1 border-primary/30 text-primary hover:bg-primary/10 hover:border-primary"
                        >
                          <Edit3 className="w-4 h-4 mr-2" />
                          Edit
                        </Button>
                        <Button
                          onClick={(e) => handleDeleteClick(e, review)}
                          variant="outline"
                          size="sm"
                          className="flex-1 border-destructive/30 text-destructive hover:bg-destructive/10 hover:border-destructive"
                        >
                          <Trash2 className="w-4 h-4 mr-2" />
                          Delete
                        </Button>
                        <Button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedReviewDetail(review);
                            setReviewDetailModalOpen(true);
                          }}
                          variant="outline"
                          size="sm"
                          className="flex-1 border-secondary/30 text-secondary hover:bg-secondary/10 hover:border-secondary"
                        >
                          <Info className="w-4 h-4 mr-2" />
                          More Info
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </section>

          {/* Your Collections */}
          <section className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-xl md:text-2xl text-foreground">Your Collections</h2>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => onNavigate?.("your-space-lists")}
                className="text-primary hover:text-primary/80 hover:bg-primary/10"
              >
                View All
              </Button>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {myLists.slice(0, 3).map((list) => (
                <Card 
                  key={list.id} 
                  onClick={() => onNavigate?.(`collection-${list.id}`)}
                  className="p-4 bg-card border-border hover:border-primary/50 transition-all shadow-soft hover:shadow-medium cursor-pointer group"
                >
                  <div className="grid grid-cols-2 gap-2 mb-3 rounded-lg overflow-hidden">
                    {list.coverImages.slice(0, 4).map((cover, i) => (
                      <div key={i} className="aspect-square overflow-hidden rounded-md">
                        <img
                          src={cover}
                          alt=""
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                      </div>
                    ))}
                  </div>
                  <h4 className="text-foreground mb-1 truncate">{list.title}</h4>
                  <p className="text-sm text-muted-foreground mb-2 line-clamp-1">{list.description}</p>
                  <Badge className="bg-primary/10 text-primary border-0 text-xs">
                    {list.albumCount} albums
                  </Badge>
                </Card>
              ))}
            </div>
          </section>
        </TabsContent>

        {/* Community Tab */}
        <TabsContent value="community" className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="text-xl md:text-2xl text-foreground">Community Feed</h2>
              <Badge className="bg-chart-3/20 text-chart-3 border-0">
                <Flame className="w-3 h-3 mr-1" />
                Trending
              </Badge>
            </div>
          </div>

          <div className="grid gap-4">
            {friendsReviews.map((review, index) => (
              <Card 
                key={`friend-review-${review.id}-${index}`}
                onClick={() => handleReviewClick(review)}
                className="p-4 md:p-6 bg-card border-border hover:border-primary/50 transition-all shadow-soft hover:shadow-medium cursor-pointer"
              >
                {/* User Header */}
                <div className="flex items-center gap-3 mb-4">
                  <Avatar className="w-10 h-10 ring-2 ring-border hover:ring-primary transition">
                    <img src={review.userAvatar} alt={review.userName} className="object-cover" />
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-foreground">{review.userName}</span>
                      <span className="text-muted-foreground text-sm">reviewed</span>
                      <span className="text-foreground truncate">{review.albumTitle}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{review.timestamp}</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div 
                    className="flex-shrink-0 cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenAlbum?.();
                    }}
                  >
                    <img
                      src={review.albumCover}
                      alt={review.albumTitle}
                      className="w-20 h-20 md:w-24 md:h-24 rounded-lg object-cover hover:scale-105 transition-transform"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1 mb-2">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(review.rating)
                              ? "text-primary fill-primary"
                              : "text-muted"
                          }`}
                        />
                      ))}
                      <span className="ml-1 text-sm text-foreground">{review.rating}</span>
                    </div>

                    <p className="text-sm text-muted-foreground mb-2">{review.albumArtist}</p>
                    <p className="text-foreground mb-3 line-clamp-2">{review.content}</p>

                    {review.tags && (
                      <div className="flex flex-wrap gap-2 mb-3">
                        {review.tags.map((tag) => (
                          <Badge key={tag} className="bg-secondary/10 text-secondary border-0 text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}

                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleLike(review.id);
                        }}
                        className={`flex items-center gap-1 transition ${
                          likedReviews.includes(review.id) ? "text-secondary" : "hover:text-secondary"
                        }`}
                      >
                        <Heart className={`w-4 h-4 ${likedReviews.includes(review.id) ? "fill-secondary" : ""}`} />
                        {review.likes + (likedReviews.includes(review.id) ? 1 : 0)}
                      </button>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedReview(review);
                          setCommentsModalOpen(true);
                        }}
                        className="flex items-center gap-1 hover:text-primary transition"
                      >
                        <MessageCircle className="w-4 h-4" />
                        {review.comments}
                      </button>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleShare(review);
                        }}
                        className="flex items-center gap-1 hover:text-foreground transition"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Discover Tab */}
        <TabsContent value="discover" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* New Releases */}
            <section className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary/10">
                  <TrendingUp className="w-4 h-4 text-primary" />
                </div>
                <h2 className="text-xl text-foreground">New Releases</h2>
                <Badge className="bg-primary/10 text-primary border-0 text-xs">
                  <Sparkles className="w-3 h-3 mr-1" />
                  Fresh
                </Badge>
              </div>
              
              <div className="space-y-3">
                {newReleases.map((release) => (
                  <Card 
                    key={release.id} 
                    className="p-4 bg-card border-border hover:border-primary/50 transition-all shadow-soft hover:shadow-medium cursor-pointer group"
                    onClick={() => onOpenAlbum?.()}
                  >
                    <div className="flex gap-3">
                      <div className="flex-shrink-0">
                        <img
                          src={release.cover}
                          alt={release.title}
                          className="w-16 h-16 rounded-md object-cover group-hover:scale-105 transition-transform"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-foreground truncate group-hover:text-primary transition mb-0.5">{release.title}</p>
                        <p className="text-sm text-muted-foreground truncate mb-1">{release.artist}</p>
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className="bg-secondary/10 text-secondary border-0 text-xs px-1.5 py-0">
                            {release.type}
                          </Badge>
                          <span className="text-xs text-muted-foreground">{release.releaseDate}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>{release.trackCount} tracks</span>
                          <span>•</span>
                          <span>{release.duration}</span>
                        </div>
                      </div>
                      {release.previewUrl && (
                        <div className="flex-shrink-0 self-center" onClick={(e) => e.stopPropagation()}>
                          <PreviewButton
                            previewUrl={release.previewUrl}
                            trackName={release.title}
                            artist={release.artist}
                            size="sm"
                            variant="ghost"
                          />
                        </div>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            </section>

            {/* Upcoming Events */}
            <section className="space-y-4">
              <div className="flex items-center gap-2">
                <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-secondary/10">
                  <MapPin className="w-4 h-4 text-secondary" />
                </div>
                <h2 className="text-xl text-foreground">Concerts</h2>
              </div>
              
              <div className="space-y-3">
                {upcomingEvents.map((event) => (
                  <Card 
                    key={event.id} 
                    className="p-4 bg-card border-border hover:border-secondary/50 transition-all shadow-soft hover:shadow-medium cursor-pointer group"
                    onClick={() => {
                      setSelectedEvent(event);
                      setEventModalOpen(true);
                    }}
                  >
                    <div className="flex items-start gap-2 mb-2">
                      <Music2 className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                      <p className="text-foreground group-hover:text-secondary transition flex-1">{event.artistName}</p>
                    </div>
                    <p className="text-sm text-muted-foreground mb-1 pl-6">{event.venue}</p>
                    <p className="text-sm text-muted-foreground mb-2 pl-6">{event.city}</p>
                    <div className="flex items-center justify-between pl-6">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Calendar className="w-3 h-3" />
                        <span>{event.date}</span>
                      </div>
                      <Badge className="bg-chart-3/10 text-chart-3 border-0 text-xs">
                        Tickets
                      </Badge>
                    </div>
                  </Card>
                ))}
              </div>
            </section>
          </div>

          {/* Now Playing Activity */}
          <section className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-chart-3/10">
                <Play className="w-4 h-4 text-chart-3" />
                <div className="absolute -right-1 -top-1 w-2 h-2 bg-chart-3 rounded-full animate-pulse"></div>
              </div>
              <h2 className="text-xl text-foreground">Now Playing</h2>
            </div>
            
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {membersActivity.slice(0, 4).map((activity) => (
                <Card 
                  key={activity.id} 
                  className="p-3 bg-card border-border hover:border-primary/50 transition-all shadow-soft hover:shadow-medium group"
                >
                  <div 
                    className="flex items-center gap-2 mb-2 cursor-pointer hover:opacity-80 transition-opacity"
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigate?.("profile");
                    }}
                  >
                    <Avatar className="w-8 h-8 ring-2 ring-transparent group-hover:ring-primary transition">
                      <img src={activity.userAvatar} alt={activity.userName} className="object-cover" />
                    </Avatar>
                    <span className="text-sm text-foreground truncate">{activity.userName}</span>
                  </div>
                  <div 
                    className="cursor-pointer mb-2"
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenAlbum?.();
                    }}
                  >
                    <img
                      src={activity.albumCover}
                      alt={activity.trackTitle}
                      className="w-full aspect-square rounded-md object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                  <p className="text-sm text-foreground truncate mb-0.5">{activity.trackTitle}</p>
                  <p className="text-xs text-muted-foreground truncate">{activity.artistName}</p>
                </Card>
              ))}
            </div>
          </section>
        </TabsContent>

        {/* Search Tab */}
        <TabsContent value="search" className="space-y-6">
          {!searchQuery.trim() ? (
            <EmptyState
              icon={Search}
              title="Start searching"
              description="Enter a search query to find albums, artists, users, and reviews"
            />
          ) : !hasSearchResults ? (
            <EmptyState
              icon={Search}
              title="No results found"
              description={`No results found for "${searchQuery}"`}
            />
          ) : (
            <div className="space-y-6">
              {/* Albums */}
              {filteredAlbums.length > 0 && (
                <section className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Disc3 className="w-5 h-5 text-primary" />
                    <h2 className="text-xl text-foreground">Albums ({filteredAlbums.length})</h2>
                  </div>
                  <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {filteredAlbums.slice(0, 8).map((album) => (
                      <Card
                        key={album.id}
                        onClick={() => onOpenAlbum?.(album.id)}
                        className="p-4 bg-card border-border hover:border-primary/50 transition-all shadow-soft hover:shadow-medium cursor-pointer group"
                      >
                        <img
                          src={album.cover}
                          alt={album.title}
                          className="w-full aspect-square rounded-lg object-cover mb-3 group-hover:scale-105 transition-transform"
                        />
                        <h3 className="text-foreground truncate mb-1 group-hover:text-primary transition">{album.title}</h3>
                        <p className="text-sm text-muted-foreground truncate">{album.artist}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Badge className="bg-secondary/10 text-secondary border-0 text-xs">
                            {album.year}
                          </Badge>
                          <div className="flex items-center gap-1">
                            <Star className="w-3 h-3 text-primary fill-primary" />
                            <span className="text-xs text-foreground">{album.rating}</span>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </section>
              )}

              {/* Users */}
              {filteredUsers.length > 0 && (
                <section className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Users className="w-5 h-5 text-secondary" />
                    <h2 className="text-xl text-foreground">Users ({filteredUsers.length})</h2>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    {filteredUsers.slice(0, 6).map((user) => (
                      <Card
                        key={user.id}
                        className="p-4 bg-card border-border hover:border-secondary/50 transition-all shadow-soft hover:shadow-medium cursor-pointer group"
                      >
                        <div className="flex items-center gap-4">
                          <Avatar className="w-16 h-16 ring-2 ring-border group-hover:ring-secondary transition">
                            <img src={user.avatar} alt={user.name} className="object-cover" />
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <h3 className="text-foreground mb-1 truncate group-hover:text-secondary transition">{user.name}</h3>
                            <p className="text-sm text-muted-foreground mb-2 truncate">@{user.username}</p>
                            <Badge className="bg-primary/10 text-primary border-0 text-xs">
                              {user.matchPercentage}% match
                            </Badge>
                          </div>
                          <Button 
                            size="sm" 
                            variant={isFollowing(user.id) ? "outline" : "outline"}
                            className={
                              isFollowing(user.id)
                                ? "border-border text-muted-foreground hover:bg-destructive/10 hover:text-destructive hover:border-destructive"
                                : "border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                            }
                            onClick={(e) => {
                              e.stopPropagation();
                              handleFollowToggle(user.id, user.name);
                            }}
                          >
                            {isFollowing(user.id) ? (
                              <UserPlus className="w-4 h-4" />
                            ) : (
                              <UserPlus className="w-4 h-4" />
                            )}
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                </section>
              )}

              {/* Reviews */}
              {filteredReviews.length > 0 && (
                <section className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-chart-4" />
                    <h2 className="text-xl text-foreground">Reviews ({filteredReviews.length})</h2>
                  </div>
                  <div className="grid gap-4">
                    {filteredReviews.slice(0, 5).map((review, index) => (
                      <Card 
                        key={`search-review-${review.id}-${index}`} 
                        className="p-4 md:p-6 bg-card border-border hover:border-primary/50 transition-all shadow-soft hover:shadow-medium"
                      >
                        <div className="flex items-center gap-3 mb-3">
                          <Avatar className="w-10 h-10 ring-2 ring-border">
                            <img src={review.userAvatar} alt={review.userName} className="object-cover" />
                          </Avatar>
                          <div>
                            <span className="text-foreground">{review.userName}</span>
                            <p className="text-xs text-muted-foreground">{review.timestamp}</p>
                          </div>
                        </div>

                        <div className="flex gap-4">
                          <div 
                            className="flex-shrink-0 cursor-pointer"
                            onClick={() => onOpenAlbum?.()}
                          >
                            <img
                              src={review.albumCover}
                              alt={review.albumTitle}
                              className="w-20 h-20 rounded-lg object-cover hover:scale-105 transition-transform"
                            />
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-4 mb-2">
                              <div>
                                <h3 className="text-foreground mb-1 truncate">{review.albumTitle}</h3>
                                <p className="text-sm text-muted-foreground truncate">{review.albumArtist}</p>
                              </div>
                              <div className="flex items-center gap-1">
                                <Star className="w-4 h-4 text-primary fill-primary" />
                                <span className="text-foreground">{review.rating}</span>
                              </div>
                            </div>
                            
                            <p className="text-foreground text-sm line-clamp-2">{review.content}</p>
                          </div>
                        </div>
                      </Card>
                    ))}
                  </div>
                </section>
              )}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Comments Modal */}
      {selectedReview && (
        <CommentsModal
          isOpen={commentsModalOpen}
          onClose={() => {
            setCommentsModalOpen(false);
            setSelectedReview(null);
          }}
          review={selectedReview}
        />
      )}

      {/* Event Modal */}
      <EventModal
        event={selectedEvent}
        isOpen={eventModalOpen}
        onClose={() => {
          setEventModalOpen(false);
          setSelectedEvent(null);
        }}
      />

      {/* Review Detail Modal */}
      <ReviewDetailModal
        review={selectedReviewDetail}
        isOpen={reviewDetailModalOpen}
        onClose={() => setReviewDetailModalOpen(false)}
        onOpenComments={() => {
          setCommentsModalOpen(true);
        }}
        onOpenAlbum={onOpenAlbum}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">Delete Review?</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">
              Are you sure you want to delete this review? This action cannot be undone and the review will be permanently removed from all feeds and pages.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-border text-foreground hover:bg-accent">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}