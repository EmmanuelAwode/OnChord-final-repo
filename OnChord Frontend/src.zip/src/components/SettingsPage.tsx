import { useState, useEffect, useRef } from "react";
import { Card } from "./ui/card";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Slider } from "./ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Input } from "./ui/input";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "./ui/alert-dialog";
import { toast } from "sonner@2.0.3";
import { PageHeader } from "./PageHeader";
import { 
  Settings, 
  Bell, 
  Lock, 
  Palette, 
  User, 
  Music, 
  Globe, 
  Type,
  Volume2,
  Download,
  Zap,
  Eye,
  Keyboard,
  Archive,
  FileText,
  Shield,
  Share2,
  UserPlus,
  Heart,
  MessageCircle,
  Star,
  Radio,
  BarChart3,
  Filter,
  Clock,
  Moon,
  Sun,
  Monitor,
  ChevronRight,
  Check,
  LogOut
} from "lucide-react";
import { motion } from "motion/react";

const accentColors = [
  { name: "Purple", value: "#A78BFA", id: "purple" },
  { name: "Blue", value: "#60A5FA", id: "blue" },
  { name: "Pink", value: "#F472B6", id: "pink" },
  { name: "Green", value: "#34D399", id: "green" },
  { name: "Orange", value: "#FBBF24", id: "orange" },
];

const languages = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "es", name: "Español", flag: "🇪🇸" },
  { code: "fr", name: "Français", flag: "🇫🇷" },
  { code: "de", name: "Deutsch", flag: "🇩🇪" },
  { code: "it", name: "Italiano", flag: "🇮🇹" },
  { code: "pt", name: "Português", flag: "🇧🇷" },
  { code: "ja", name: "日本語", flag: "🇯🇵" },
  { code: "ko", name: "한국어", flag: "🇰🇷" },
  { code: "zh", name: "中文", flag: "🇨🇳" },
];

const dateFormats = [
  { id: "mdy", label: "MM/DD/YYYY", example: "10/01/2025" },
  { id: "dmy", label: "DD/MM/YYYY", example: "01/10/2025" },
  { id: "ymd", label: "YYYY-MM-DD", example: "2025-10-01" },
];

const timeFormats = [
  { id: "12h", label: "12-hour (AM/PM)", example: "2:30 PM" },
  { id: "24h", label: "24-hour", example: "14:30" },
];

interface SettingsPageProps {
  darkMode: boolean;
  onDarkModeChange: (value: boolean) => void;
  accentColor: string;
  onAccentColorChange: (value: string) => void;
  onLogout?: () => void;
  onBack?: () => void;
  canGoBack?: boolean;
  initialTab?: string;
}

export function SettingsPage({ 
  darkMode, 
  onDarkModeChange, 
  accentColor, 
  onAccentColorChange,
  onLogout,
  onBack,
  canGoBack,
  initialTab = "appearance"
}: SettingsPageProps) {
  const [activeTab, setActiveTab] = useState(initialTab);
  const connectedServicesRef = useRef<HTMLDivElement>(null);
  const [shouldHighlight, setShouldHighlight] = useState(false);
  
  // Update active tab when initialTab prop changes
  useEffect(() => {
    setActiveTab(initialTab);
    // If navigating to account tab, highlight the connected services section
    if (initialTab === "account") {
      setShouldHighlight(true);
      // Scroll to connected services after a short delay to ensure the tab content is rendered
      setTimeout(() => {
        connectedServicesRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        // Remove highlight after 2 seconds
        setTimeout(() => setShouldHighlight(false), 2000);
      }, 300);
    }
  }, [initialTab]);
  
  // Appearance settings
  const [themeMode, setThemeMode] = useState<"light" | "dark" | "auto">(darkMode ? "dark" : "light");
  const [fontSize, setFontSize] = useState([16]);
  const [displayDensity, setDisplayDensity] = useState("comfortable");
  const [reduceMotion, setReduceMotion] = useState(false);
  const [highContrast, setHighContrast] = useState(false);

  // Language & Region
  const [language, setLanguage] = useState("en");
  const [dateFormat, setDateFormat] = useState("mdy");
  const [timeFormat, setTimeFormat] = useState("12h");
  const [timezone, setTimezone] = useState("auto");

  // Audio settings
  const [audioQuality, setAudioQuality] = useState("high");
  const [normalizeVolume, setNormalizeVolume] = useState(true);
  const [crossfade, setCrossfade] = useState(true);
  const [crossfadeDuration, setCrossfadeDuration] = useState([3]);
  const [gaplessPlayback, setGaplessPlayback] = useState(true);
  const [autoplay, setAutoplay] = useState(true);

  // Notifications
  const [notifications, setNotifications] = useState({
    likes: true,
    comments: true,
    follows: true,
    messages: true,
    newReleases: true,
    recommendations: true,
    weeklyRecap: true,
    friendActivity: false,
    tasteMatch: true,
    playlistUpdates: true,
  });
  const [notificationSound, setNotificationSound] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);

  // Privacy
  const [privacy, setPrivacy] = useState({
    publicReviews: true,
    publicLists: true,
    showActivity: true,
    allowMessages: true,
    showListeningHistory: true,
    discoverableByEmail: false,
    showOnlineStatus: true,
    allowTagging: true,
  });

  // Content preferences
  const [explicitContent, setExplicitContent] = useState(true);
  const [contentLanguages, setContentLanguages] = useState(["en"]);
  const [autoplayVideos, setAutoplayVideos] = useState(false);

  // Advanced
  const [betaFeatures, setBetaFeatures] = useState(false);
  const [analyticsEnabled, setAnalyticsEnabled] = useState(true);

  // Modals
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [showDeactivateDialog, setShowDeactivateDialog] = useState(false);

  const handleThemeChange = (mode: "light" | "dark" | "auto") => {
    setThemeMode(mode);
    if (mode === "auto") {
      const systemPrefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      onDarkModeChange(systemPrefersDark);
    } else {
      onDarkModeChange(mode === "dark");
    }
  };

  const handleFontSizeChange = (value: number[]) => {
    setFontSize(value);
    document.documentElement.style.setProperty("--font-size", `${value[0]}px`);
    
    // Add animation class temporarily for smooth transition
    document.body.classList.add('font-transition-active');
    setTimeout(() => {
      document.body.classList.remove('font-transition-active');
    }, 600);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 animate-fade-in">
      {/* Header */}
      <PageHeader
        title="Settings"
        subtitle="Customize your OnChord experience"
        showBackButton={canGoBack}
        onBack={onBack}
      />

      {/* Tabs Navigation */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="w-full justify-start overflow-x-auto bg-muted/50 p-1 h-auto flex-wrap">
          <TabsTrigger value="appearance" className="flex items-center gap-2">
            <Palette className="w-4 h-4" />
            <span className="hidden sm:inline">Appearance</span>
          </TabsTrigger>
          <TabsTrigger value="language" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            <span className="hidden sm:inline">Language</span>
          </TabsTrigger>
          <TabsTrigger value="audio" className="flex items-center gap-2">
            <Volume2 className="w-4 h-4" />
            <span className="hidden sm:inline">Audio</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="w-4 h-4" />
            <span className="hidden sm:inline">Notifications</span>
          </TabsTrigger>
          <TabsTrigger value="privacy" className="flex items-center gap-2">
            <Lock className="w-4 h-4" />
            <span className="hidden sm:inline">Privacy</span>
          </TabsTrigger>
          <TabsTrigger value="content" className="flex items-center gap-2">
            <Filter className="w-4 h-4" />
            <span className="hidden sm:inline">Content</span>
          </TabsTrigger>
          <TabsTrigger value="account" className="flex items-center gap-2">
            <User className="w-4 h-4" />
            <span className="hidden sm:inline">Account</span>
          </TabsTrigger>
        </TabsList>

        {/* Appearance Settings */}
        <TabsContent value="appearance" className="space-y-6 mt-6">
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-primary/20 p-2 rounded-lg">
                <Palette className="w-5 h-5 text-primary" />
              </div>
              <h2 className="text-xl text-foreground">Theme</h2>
            </div>

            <div className="space-y-6">
              {/* Theme Mode */}
              <div>
                <Label className="text-foreground mb-3 block">Display Mode</Label>
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { id: "light", label: "Light", icon: Sun },
                    { id: "dark", label: "Dark", icon: Moon },
                    { id: "auto", label: "Auto", icon: Monitor },
                  ].map(({ id, label, icon: Icon }) => (
                    <button
                      key={id}
                      onClick={() => handleThemeChange(id as any)}
                      className={`relative p-4 rounded-lg border-2 transition-all ${
                        themeMode === id
                          ? "border-primary bg-primary/10"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <Icon className="w-6 h-6 text-foreground mx-auto mb-2" />
                      <p className="text-sm text-foreground">{label}</p>
                      {themeMode === id && (
                        <div className="absolute top-2 right-2">
                          <Check className="w-4 h-4 text-primary" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <Separator className="bg-border" />

              {/* Accent Color */}
              <div>
                <Label className="text-foreground mb-3 block">Accent Color</Label>
                <p className="text-sm text-muted-foreground mb-4">
                  Choose your preferred accent color
                </p>
                <div className="flex flex-wrap gap-3">
                  {accentColors.map((color) => (
                    <button
                      key={color.id}
                      onClick={() => onAccentColorChange(color.id)}
                      className={`relative w-16 h-16 rounded-lg transition hover:scale-105 ${
                        accentColor === color.id ? "ring-2 ring-offset-2 ring-offset-card" : ""
                      }`}
                      style={{
                        backgroundColor: color.value,
                        ringColor: color.value,
                      }}
                    >
                      {accentColor === color.id && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-6 h-6 bg-white rounded-full flex items-center justify-center">
                            <Check className="w-4 h-4" />
                          </div>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <Separator className="bg-border" />

              {/* Font Size */}
              <div>
                <Label className="text-foreground mb-3 block">Font Size</Label>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Small</span>
                    <span className="text-sm text-muted-foreground">{fontSize[0]}px</span>
                    <span className="text-sm text-muted-foreground">Large</span>
                  </div>
                  <Slider
                    value={fontSize}
                    onValueChange={handleFontSizeChange}
                    min={12}
                    max={20}
                    step={1}
                    className="w-full"
                  />
                </div>
              </div>

              <Separator className="bg-border" />

              {/* Display Density */}
              <div>
                <Label className="text-foreground mb-3 block">Display Density</Label>
                <Select value={displayDensity} onValueChange={setDisplayDensity}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="compact">Compact - More content</SelectItem>
                    <SelectItem value="comfortable">Comfortable - Balanced</SelectItem>
                    <SelectItem value="spacious">Spacious - Easy on eyes</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator className="bg-border" />

              {/* Accessibility */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-foreground">Reduce Motion</Label>
                    <p className="text-sm text-muted-foreground">
                      Minimize animations and transitions
                    </p>
                  </div>
                  <Switch checked={reduceMotion} onCheckedChange={setReduceMotion} />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-foreground">High Contrast</Label>
                    <p className="text-sm text-muted-foreground">
                      Increase color contrast for better visibility
                    </p>
                  </div>
                  <Switch checked={highContrast} onCheckedChange={setHighContrast} />
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Language & Region Settings */}
        <TabsContent value="language" className="space-y-6 mt-6">
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-secondary/20 p-2 rounded-lg">
                <Globe className="w-5 h-5 text-secondary" />
              </div>
              <h2 className="text-xl text-foreground">Language & Region</h2>
            </div>

            <div className="space-y-6">
              {/* Language Selection */}
              <div>
                <Label className="text-foreground mb-3 block">Display Language</Label>
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        <span className="flex items-center gap-2">
                          <span>{lang.flag}</span>
                          <span>{lang.name}</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-sm text-muted-foreground mt-2">
                  Changes will take effect after restarting the app
                </p>
              </div>

              <Separator className="bg-border" />

              {/* Date Format */}
              <div>
                <Label className="text-foreground mb-3 block">Date Format</Label>
                <Select value={dateFormat} onValueChange={setDateFormat}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {dateFormats.map((format) => (
                      <SelectItem key={format.id} value={format.id}>
                        {format.label} - {format.example}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Separator className="bg-border" />

              {/* Time Format */}
              <div>
                <Label className="text-foreground mb-3 block">Time Format</Label>
                <Select value={timeFormat} onValueChange={setTimeFormat}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {timeFormats.map((format) => (
                      <SelectItem key={format.id} value={format.id}>
                        {format.label} - {format.example}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Separator className="bg-border" />

              {/* Timezone */}
              <div>
                <Label className="text-foreground mb-3 block">Timezone</Label>
                <Select value={timezone} onValueChange={setTimezone}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Automatic (Detect from device)</SelectItem>
                    <SelectItem value="utc">UTC (Coordinated Universal Time)</SelectItem>
                    <SelectItem value="est">EST (Eastern Standard Time)</SelectItem>
                    <SelectItem value="pst">PST (Pacific Standard Time)</SelectItem>
                    <SelectItem value="cet">CET (Central European Time)</SelectItem>
                    <SelectItem value="jst">JST (Japan Standard Time)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Audio Settings */}
        <TabsContent value="audio" className="space-y-6 mt-6">
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-chart-1/20 p-2 rounded-lg">
                <Volume2 className="w-5 h-5 text-chart-1" />
              </div>
              <h2 className="text-xl text-foreground">Playback Settings</h2>
            </div>

            <div className="space-y-6">
              {/* Audio Quality */}
              <div>
                <Label className="text-foreground mb-3 block">Streaming Quality</Label>
                <Select value={audioQuality} onValueChange={setAudioQuality}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low - 96 kbps (Save data)</SelectItem>
                    <SelectItem value="normal">Normal - 160 kbps</SelectItem>
                    <SelectItem value="high">High - 320 kbps (Recommended)</SelectItem>
                    <SelectItem value="lossless">Lossless - FLAC</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator className="bg-border" />

              {/* Playback Features */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-foreground">Normalize Volume</Label>
                    <p className="text-sm text-muted-foreground">
                      Keep volume consistent across tracks
                    </p>
                  </div>
                  <Switch checked={normalizeVolume} onCheckedChange={setNormalizeVolume} />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-foreground">Crossfade</Label>
                    <p className="text-sm text-muted-foreground">
                      Smooth transitions between songs
                    </p>
                  </div>
                  <Switch checked={crossfade} onCheckedChange={setCrossfade} />
                </div>

                {crossfade && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="pl-4 space-y-3"
                  >
                    <Label className="text-sm text-muted-foreground">Crossfade Duration</Label>
                    <div className="flex items-center gap-4">
                      <Slider
                        value={crossfadeDuration}
                        onValueChange={setCrossfadeDuration}
                        min={0}
                        max={12}
                        step={1}
                        className="flex-1"
                      />
                      <span className="text-sm text-foreground w-12">{crossfadeDuration[0]}s</span>
                    </div>
                  </motion.div>
                )}

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-foreground">Gapless Playback</Label>
                    <p className="text-sm text-muted-foreground">
                      No silence between tracks
                    </p>
                  </div>
                  <Switch checked={gaplessPlayback} onCheckedChange={setGaplessPlayback} />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-foreground">Autoplay</Label>
                    <p className="text-sm text-muted-foreground">
                      Continue with similar tracks when queue ends
                    </p>
                  </div>
                  <Switch checked={autoplay} onCheckedChange={setAutoplay} />
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Notifications Settings */}
        <TabsContent value="notifications" className="space-y-6 mt-6">
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-secondary/20 p-2 rounded-lg">
                <Bell className="w-5 h-5 text-secondary" />
              </div>
              <h2 className="text-xl text-foreground">Notification Preferences</h2>
            </div>

            <div className="space-y-6">
              {/* Notification Channels */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-foreground">Push Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive notifications on this device
                    </p>
                  </div>
                  <Switch checked={pushNotifications} onCheckedChange={setPushNotifications} />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-foreground">Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Receive updates via email
                    </p>
                  </div>
                  <Switch checked={emailNotifications} onCheckedChange={setEmailNotifications} />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-foreground">Notification Sounds</Label>
                    <p className="text-sm text-muted-foreground">
                      Play sound when notifications arrive
                    </p>
                  </div>
                  <Switch checked={notificationSound} onCheckedChange={setNotificationSound} />
                </div>
              </div>

              <Separator className="bg-border" />

              {/* Notification Types */}
              <div>
                <Label className="text-foreground mb-4 block">What to be notified about</Label>
                <div className="space-y-4">
                  {[
                    { key: "likes", icon: Heart, label: "Likes", desc: "When someone likes your review" },
                    { key: "comments", icon: MessageCircle, label: "Comments", desc: "When someone comments on your content" },
                    { key: "follows", icon: UserPlus, label: "New Followers", desc: "When someone starts following you" },
                    { key: "messages", icon: MessageCircle, label: "Messages", desc: "Direct message notifications" },
                    { key: "newReleases", icon: Music, label: "New Releases", desc: "From artists you follow" },
                    { key: "recommendations", icon: Star, label: "Recommendations", desc: "Personalized music suggestions" },
                    { key: "weeklyRecap", icon: BarChart3, label: "Weekly Recap", desc: "Your listening statistics" },
                    { key: "friendActivity", icon: Radio, label: "Friend Activity", desc: "What your friends are listening to" },
                    { key: "tasteMatch", icon: Zap, label: "Taste Matches", desc: "When you match with other users" },
                    { key: "playlistUpdates", icon: Music, label: "Playlist Updates", desc: "Changes to collaborative playlists" },
                  ].map(({ key, icon: Icon, label, desc }) => (
                    <div key={key} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="bg-muted p-2 rounded-lg">
                          <Icon className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <div>
                          <Label className="text-foreground">{label}</Label>
                          <p className="text-sm text-muted-foreground">{desc}</p>
                        </div>
                      </div>
                      <Switch
                        checked={notifications[key as keyof typeof notifications]}
                        onCheckedChange={(checked) =>
                          setNotifications({ ...notifications, [key]: checked })
                        }
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Privacy Settings */}
        <TabsContent value="privacy" className="space-y-6 mt-6">
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-chart-3/20 p-2 rounded-lg">
                <Lock className="w-5 h-5 text-chart-3" />
              </div>
              <h2 className="text-xl text-foreground">Privacy & Security</h2>
            </div>

            <div className="space-y-6">
              {/* Profile Privacy */}
              <div>
                <Label className="text-foreground mb-4 block">Profile Visibility</Label>
                <div className="space-y-4">
                  {[
                    { key: "publicReviews", label: "Public Reviews", desc: "Allow others to see your reviews" },
                    { key: "publicLists", label: "Public Playlists", desc: "Make your playlists visible to everyone" },
                    { key: "showActivity", label: "Activity Status", desc: "Show your listening activity to friends" },
                    { key: "showListeningHistory", label: "Listening History", desc: "Display your recent tracks publicly" },
                    { key: "showOnlineStatus", label: "Online Status", desc: "Let others see when you're active" },
                  ].map(({ key, label, desc }) => (
                    <div key={key} className="flex items-center justify-between">
                      <div>
                        <Label className="text-foreground">{label}</Label>
                        <p className="text-sm text-muted-foreground">{desc}</p>
                      </div>
                      <Switch
                        checked={privacy[key as keyof typeof privacy]}
                        onCheckedChange={(checked) =>
                          setPrivacy({ ...privacy, [key]: checked })
                        }
                      />
                    </div>
                  ))}
                </div>
              </div>

              <Separator className="bg-border" />

              {/* Communication Privacy */}
              <div>
                <Label className="text-foreground mb-4 block">Communication</Label>
                <div className="space-y-4">
                  {[
                    { key: "allowMessages", label: "Direct Messages", desc: "Allow others to message you" },
                    { key: "allowTagging", label: "Tagging", desc: "Let others tag you in posts" },
                    { key: "discoverableByEmail", label: "Email Discovery", desc: "Allow people to find you by email" },
                  ].map(({ key, label, desc }) => (
                    <div key={key} className="flex items-center justify-between">
                      <div>
                        <Label className="text-foreground">{label}</Label>
                        <p className="text-sm text-muted-foreground">{desc}</p>
                      </div>
                      <Switch
                        checked={privacy[key as keyof typeof privacy]}
                        onCheckedChange={(checked) =>
                          setPrivacy({ ...privacy, [key]: checked })
                        }
                      />
                    </div>
                  ))}
                </div>
              </div>

              <Separator className="bg-border" />

              {/* Data Controls */}
              <div>
                <Label className="text-foreground mb-4 block">Data Management</Label>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-between border-border">
                    <span className="flex items-center gap-2">
                      <Download className="w-4 h-4" />
                      Download Your Data
                    </span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" className="w-full justify-between border-border">
                    <span className="flex items-center gap-2">
                      <Archive className="w-4 h-4" />
                      Request Account Archive
                    </span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" className="w-full justify-between border-border">
                    <span className="flex items-center gap-2">
                      <FileText className="w-4 h-4" />
                      Privacy Policy
                    </span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Content Preferences */}
        <TabsContent value="content" className="space-y-6 mt-6">
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-chart-4/20 p-2 rounded-lg">
                <Filter className="w-5 h-5 text-chart-4" />
              </div>
              <h2 className="text-xl text-foreground">Content Preferences</h2>
            </div>

            <div className="space-y-6">
              {/* Content Filtering */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-foreground">Allow Explicit Content</Label>
                    <p className="text-sm text-muted-foreground">
                      Show music with explicit lyrics
                    </p>
                  </div>
                  <Switch checked={explicitContent} onCheckedChange={setExplicitContent} />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-foreground">Autoplay Videos</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically play video content
                    </p>
                  </div>
                  <Switch checked={autoplayVideos} onCheckedChange={setAutoplayVideos} />
                </div>
              </div>

              <Separator className="bg-border" />

              {/* Content Languages */}
              <div>
                <Label className="text-foreground mb-3 block">Preferred Content Languages</Label>
                <p className="text-sm text-muted-foreground mb-3">
                  Select languages for music recommendations
                </p>
                <div className="flex flex-wrap gap-2">
                  {languages.slice(0, 6).map((lang) => (
                    <Badge
                      key={lang.code}
                      variant="outline"
                      className={`cursor-pointer ${
                        contentLanguages.includes(lang.code)
                          ? "bg-primary/20 text-primary border-primary"
                          : ""
                      }`}
                      onClick={() => {
                        if (contentLanguages.includes(lang.code)) {
                          setContentLanguages(contentLanguages.filter((l) => l !== lang.code));
                        } else {
                          setContentLanguages([...contentLanguages, lang.code]);
                        }
                      }}
                    >
                      <span className="mr-1">{lang.flag}</span>
                      {lang.name}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </Card>

          {/* Advanced Settings */}
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-primary/20 p-2 rounded-lg">
                <Zap className="w-5 h-5 text-primary" />
              </div>
              <h2 className="text-xl text-foreground">Advanced</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-foreground">Beta Features</Label>
                  <p className="text-sm text-muted-foreground">
                    Try experimental features (may be unstable)
                  </p>
                </div>
                <Switch checked={betaFeatures} onCheckedChange={setBetaFeatures} />
              </div>

              <Separator className="bg-border" />

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-foreground">Analytics & Diagnostics</Label>
                  <p className="text-sm text-muted-foreground">
                    Help improve OnChord by sharing usage data
                  </p>
                </div>
                <Switch checked={analyticsEnabled} onCheckedChange={setAnalyticsEnabled} />
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Account Settings */}
        <TabsContent value="account" className="space-y-6 mt-6">
          <Card className="p-6 bg-card border-border">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-chart-4/20 p-2 rounded-lg">
                <User className="w-5 h-5 text-chart-4" />
              </div>
              <h2 className="text-xl text-foreground">Account Information</h2>
            </div>

            <div className="space-y-6">
              {/* Connected Services */}
              <div 
                ref={connectedServicesRef}
                className={`transition-all duration-500 ${shouldHighlight ? 'ring-2 ring-primary/50 rounded-lg p-4 -m-4 bg-primary/5' : ''}`}
              >
                <Label className="text-foreground mb-3 block">Connected Services</Label>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-4 bg-background rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="bg-secondary/20 p-2 rounded-lg">
                        <Music className="w-5 h-5 text-secondary" />
                      </div>
                      <div>
                        <p className="text-foreground">Spotify</p>
                        <p className="text-sm text-muted-foreground">Connected</p>
                      </div>
                    </div>
                    <Badge className="bg-secondary/20 text-secondary border-0">Active</Badge>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-background rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="bg-chart-4/20 p-2 rounded-lg">
                        <svg className="w-5 h-5 text-chart-4" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                        </svg>
                      </div>
                      <div>
                        <p className="text-foreground">Instagram</p>
                        <p className="text-sm text-muted-foreground">Connected</p>
                      </div>
                    </div>
                    <Badge className="bg-chart-4/20 text-chart-4 border-0">Active</Badge>
                  </div>

                  <Button variant="outline" className="w-full border-border">
                    <Share2 className="w-4 h-4 mr-2" />
                    Connect More Services
                  </Button>
                </div>
              </div>

              <Separator className="bg-border" />

              {/* Security */}
              <div>
                <Label className="text-foreground mb-3 block">Security</Label>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-between border-border">
                    <span className="flex items-center gap-2">
                      <Lock className="w-4 h-4" />
                      Change Password
                    </span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" className="w-full justify-between border-border">
                    <span className="flex items-center gap-2">
                      <Shield className="w-4 h-4" />
                      Two-Factor Authentication
                    </span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                  <Button variant="outline" className="w-full justify-between border-border">
                    <span className="flex items-center gap-2">
                      <Eye className="w-4 h-4" />
                      Active Sessions
                    </span>
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <Separator className="bg-border" />

              {/* Session Management */}
              <div>
                <Label className="text-foreground mb-3 block">Session</Label>
                <Button 
                  variant="outline" 
                  className="w-full justify-between border-border hover:bg-destructive/10 hover:text-destructive hover:border-destructive/50"
                  onClick={onLogout}
                >
                  <span className="flex items-center gap-2">
                    <LogOut className="w-4 h-4" />
                    Log Out
                  </span>
                  <ChevronRight className="w-4 h-4" />
                </Button>
                <p className="text-xs text-muted-foreground mt-2">
                  You'll need to sign in again to access your account
                </p>
              </div>

              <Separator className="bg-border" />

              {/* Danger Zone */}
              <div>
                <Label className="text-destructive mb-3 block">Danger Zone</Label>
                <div className="space-y-3 p-4 border-2 border-destructive/20 rounded-lg">
                  <Button 
                    variant="outline" 
                    className="w-full border-destructive/50 text-destructive hover:bg-destructive/10"
                    onClick={() => setShowDeactivateDialog(true)}
                  >
                    Deactivate Account
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
                    onClick={() => setShowDeleteDialog(true)}
                  >
                    Delete Account Permanently
                  </Button>
                  <p className="text-xs text-muted-foreground text-center">
                    These actions cannot be undone. Please be certain.
                  </p>
                </div>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Save Button */}
      <div className="flex justify-end gap-3 pb-8">
        <Button 
          variant="outline" 
          className="border-border"
          onClick={() => {
            // Reset to defaults logic
            toast.info("Settings reset to defaults");
          }}
        >
          Reset to Defaults
        </Button>
        <Button 
          className="bg-primary hover:bg-primary/90 text-primary-foreground"
          onClick={() => toast.success("Settings saved successfully!")}
        >
          <Check className="w-4 h-4 mr-2" />
          Save All Changes
        </Button>
      </div>

      {/* Delete Account Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">Delete Account Permanently?</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">
              This action cannot be undone. This will permanently delete your account,
              all your reviews, playlists, and remove all your data from our servers.
              <br /><br />
              <strong className="text-destructive">Are you absolutely sure?</strong>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-border">Cancel</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-destructive hover:bg-destructive/90 text-destructive-foreground"
              onClick={() => {
                toast.error("Account deletion initiated. You will receive a confirmation email.");
                setShowDeleteDialog(false);
              }}
            >
              Delete Account
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Deactivate Account Confirmation Dialog */}
      <AlertDialog open={showDeactivateDialog} onOpenChange={setShowDeactivateDialog}>
        <AlertDialogContent className="bg-card border-border">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">Deactivate Account?</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">
              Your profile will be hidden from other users. You can reactivate your
              account anytime by logging back in. Your data will be preserved.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-border">Cancel</AlertDialogCancel>
            <AlertDialogAction 
              className="bg-destructive/80 hover:bg-destructive text-destructive-foreground"
              onClick={() => {
                toast.success("Account deactivated. You can reactivate anytime.");
                setShowDeactivateDialog(false);
              }}
            >
              Deactivate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}