import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Avatar } from "./ui/avatar";
import { Card } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Sparkles, TrendingUp, Music, Play, Clock, Headphones, Users, Disc3, Heart } from "lucide-react";
import { newReleases, membersActivity, trendingAlbums, trendingSongs } from "../lib/mockData";
import { useState } from "react";
import { useFavourites } from "../lib/useFavourites";
import { toast } from "sonner";

interface DiscoverPageProps {
  onNavigate: (page: string, options?: { insightsTab?: string }) => void;
  onOpenAlbum?: (albumId?: string) => void;
  onOpenReviewModal?: (mediaType: "album" | "song", mediaId: string, mediaTitle: string, mediaArtist: string, mediaCover: string) => void;
}

export function DiscoverPage({ onNavigate, onOpenAlbum, onOpenReviewModal }: DiscoverPageProps) {
  const [activeTab, setActiveTab] = useState("albums");
  const { isSongFavourite, toggleSong } = useFavourites();

  // Filter content based on type
  const newAlbums = newReleases.filter(r => r.type === "Album");
  const newSingles = newReleases.filter(r => r.type === "Single" || r.type === "EP");
  
  // For trending - we'll show all albums in albums tab
  const trendingAlbumsFiltered = trendingAlbums;
  const trendingSongsFiltered = trendingSongs;
  
  // For friends activity - filter by track vs album
  const friendsListeningToTracks = membersActivity;

  const handleToggleFavouriteSong = (song: any, e: React.MouseEvent) => {
    e.stopPropagation();
    const added = toggleSong({
      id: song.id,
      title: song.title,
      artist: song.artist,
      albumId: song.albumId,
      albumCover: song.albumCover,
      duration: song.duration,
    });

    if (added) {
      toast.success(`Added "${song.title}" to favourites`);
    } else {
      toast.success(`Removed "${song.title}" from favourites`);
    }
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex justify-center mb-4">
          <div className="bg-gradient-to-br from-primary/20 to-accent/20 p-4 rounded-full">
            <Sparkles className="w-8 h-8 text-primary" />
          </div>
        </div>
        <h1 className="text-3xl text-foreground">Discover</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Explore new music, trending albums, and what your friends are listening to
        </p>
      </div>

      {/* Tabs for Albums and Songs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-card border border-border w-full md:w-auto grid grid-cols-2 h-auto p-1">
          <TabsTrigger
            value="albums"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground flex items-center gap-2 py-2"
          >
            <Disc3 className="w-4 h-4" />
            Albums
          </TabsTrigger>
          <TabsTrigger
            value="songs"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground flex items-center gap-2 py-2"
          >
            <Music className="w-4 h-4" />
            Songs
          </TabsTrigger>
        </TabsList>

        {/* Albums Tab */}
        <TabsContent value="albums" className="space-y-8 mt-6">
          {/* New Releases from Followed Artists */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Disc3 className="w-5 h-5 text-primary" />
                <h2 className="text-xl text-foreground">New Albums</h2>
              </div>
              <Badge className="bg-primary/20 text-primary border-0">
                From Artists You Follow
              </Badge>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {newAlbums.map((release) => (
                <Card 
                  key={release.id}
                  className="p-4 bg-gradient-to-br from-card to-card/50 border-border hover:border-primary/50 transition-all cursor-pointer group hover:shadow-lg"
                  onClick={() => onOpenAlbum?.()}
                >
                  <div className="flex gap-4">
                    <div className="relative flex-shrink-0">
                      <img
                        src={release.cover}
                        alt={release.title}
                        className="w-24 h-24 rounded-lg object-cover shadow-md group-hover:shadow-xl transition-shadow"
                      />
                      <div className="absolute inset-0 bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Play className="w-8 h-8 text-white" fill="white" />
                      </div>
                      <Badge className="absolute -top-2 -right-2 bg-accent text-accent-foreground border-0 text-xs px-2 py-0.5">
                        New
                      </Badge>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h3 className="text-foreground font-medium mb-1 truncate group-hover:text-primary transition-colors">
                        {release.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-2 truncate">
                        {release.artist}
                      </p>
                      <div className="flex flex-col gap-1">
                        <Badge className="bg-secondary/20 text-secondary border-0 text-xs w-fit">
                          {release.type}
                        </Badge>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          <span>{release.releaseDate}</span>
                        </div>
                        {release.trackCount && release.duration && (
                          <p className="text-xs text-muted-foreground">
                            {release.trackCount} tracks • {release.duration}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </section>

          {/* Trending Albums */}
          <section>
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-secondary" />
              <h2 className="text-xl text-foreground">Trending This Week</h2>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {trendingAlbumsFiltered.map((album, index) => (
                <Card
                  key={album.id}
                  className="p-4 bg-card border-border hover:border-secondary/50 transition-all cursor-pointer group hover:shadow-lg"
                  onClick={() => onOpenAlbum?.()}
                >
                  <div className="relative mb-3">
                    <img
                      src={album.cover}
                      alt={album.title}
                      className="w-full aspect-square rounded-lg object-cover shadow-md group-hover:shadow-xl transition-shadow"
                    />
                    <div className="absolute inset-0 bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Play className="w-10 h-10 text-white" fill="white" />
                    </div>
                    <Badge className="absolute top-2 left-2 bg-secondary text-secondary-foreground border-0 text-xs">
                      #{index + 1}
                    </Badge>
                  </div>
                  
                  <h3 className="text-sm text-foreground font-medium mb-1 truncate group-hover:text-secondary transition-colors">
                    {album.title}
                  </h3>
                  <p className="text-xs text-muted-foreground truncate mb-2">
                    {album.artist}
                  </p>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Headphones className="w-3 h-3" />
                    <span>{album.plays}</span>
                  </div>
                </Card>
              ))}
            </div>
          </section>

          {/* What Friends Are Listening To */}
          <section>
            <div className="flex items-center gap-2 mb-4">
              <Headphones className="w-5 h-5 text-chart-3" />
              <h2 className="text-xl text-foreground">Friends Activity</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {friendsListeningToTracks.map((activity) => (
                <Card 
                  key={activity.id}
                  className="p-4 bg-gradient-to-br from-card to-card/50 border-border hover:border-chart-3/50 transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-4">
                    {/* Album Cover */}
                    <div 
                      className="relative flex-shrink-0 cursor-pointer"
                      onClick={() => onOpenAlbum?.()}
                    >
                      <img
                        src={activity.albumCover}
                        alt={activity.trackTitle}
                        className="w-16 h-16 rounded-lg object-cover shadow-md"
                      />
                      <div className="absolute inset-0 bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Play className="w-6 h-6 text-white" fill="white" />
                      </div>
                    </div>

                    {/* Track Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <Avatar className="w-6 h-6 border border-primary">
                          <img src={activity.userAvatar} alt={activity.userName} className="object-cover" />
                        </Avatar>
                        <span className="text-xs text-muted-foreground truncate">
                          <span className="text-foreground font-medium">{activity.userName}</span> is listening
                        </span>
                      </div>
                      <h3 className="text-sm text-foreground font-medium truncate mb-0.5">
                        {activity.trackTitle}
                      </h3>
                      <p className="text-xs text-muted-foreground truncate">
                        {activity.trackArtist}
                      </p>
                    </div>

                    {/* Timestamp */}
                    <div className="flex-shrink-0 text-xs text-muted-foreground">
                      {activity.timestamp}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </section>

          {/* Discovery Tip */}
          <Card className="p-6 bg-gradient-to-br from-primary/10 via-secondary/5 to-accent/10 border-primary/30">
            <div className="flex items-start gap-4">
              <div className="bg-gradient-to-br from-primary/30 to-accent/30 p-3 rounded-lg flex-shrink-0 ring-2 ring-primary/20">
                <Users className="w-6 h-6 text-primary drop-shadow-lg" />
              </div>
              <div>
                <h3 className="text-foreground mb-2">🎯 Discover Your Music Soulmates</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Use AI-powered taste matching to connect with people who share your exact music vibe. Get personalized recommendations and discover hidden gems.
                </p>
                <Button 
                  size="sm" 
                  className="bg-gradient-to-r from-primary via-secondary to-accent hover:from-primary/90 hover:via-secondary/90 hover:to-accent/90 text-white shadow-lg hover:shadow-xl hover:scale-105 transition-all group relative overflow-hidden"
                  onClick={() => {
                    // Navigate to Insights page with taste match tab
                    onNavigate("insights", { insightsTab: "taste" });
                  }}
                >
                  <Users className="w-4 h-4 mr-2 group-hover:rotate-12 transition-transform" />
                  Find Your Taste Matches
                  <Sparkles className="w-3 h-3 ml-2 group-hover:scale-110 transition-transform" />
                </Button>
              </div>
            </div>
          </Card>
        </TabsContent>

        {/* Songs Tab */}
        <TabsContent value="songs" className="space-y-8 mt-6">
          {/* New Releases from Followed Artists */}
          <section>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Music className="w-5 h-5 text-primary" />
                <h2 className="text-xl text-foreground">New Songs</h2>
              </div>
              <Badge className="bg-primary/20 text-primary border-0">
                From Artists You Follow
              </Badge>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {newSingles.map((release) => (
                <Card 
                  key={release.id}
                  className="p-4 bg-gradient-to-br from-card to-card/50 border-border hover:border-primary/50 transition-all cursor-pointer group hover:shadow-lg"
                  onClick={() => onOpenAlbum?.()}
                >
                  <div className="flex gap-4">
                    <div className="relative flex-shrink-0">
                      <img
                        src={release.cover}
                        alt={release.title}
                        className="w-24 h-24 rounded-lg object-cover shadow-md group-hover:shadow-xl transition-shadow"
                      />
                      <div className="absolute inset-0 bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Play className="w-8 h-8 text-white" fill="white" />
                      </div>
                      <Badge className="absolute -top-2 -right-2 bg-accent text-accent-foreground border-0 text-xs px-2 py-0.5">
                        New
                      </Badge>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <h3 className="text-foreground font-medium mb-1 truncate group-hover:text-primary transition-colors">
                        {release.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mb-2 truncate">
                        {release.artist}
                      </p>
                      <div className="flex flex-col gap-1">
                        <Badge className="bg-secondary/20 text-secondary border-0 text-xs w-fit">
                          {release.type}
                        </Badge>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          <span>{release.releaseDate}</span>
                        </div>
                        {release.trackCount && release.duration && (
                          <p className="text-xs text-muted-foreground">
                            {release.trackCount} tracks • {release.duration}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </section>

          {/* Trending Songs */}
          <section>
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-5 h-5 text-secondary" />
              <h2 className="text-xl text-foreground">Trending This Week</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {trendingSongsFiltered.map((song, index) => {
                const isFav = isSongFavourite(song.id);
                return (
                  <Card
                    key={song.id}
                    className="p-4 bg-gradient-to-br from-card to-card/50 border-border hover:border-secondary/50 transition-all group hover:shadow-lg"
                  >
                    <div className="flex gap-4">
                      {/* Album Cover */}
                      <div 
                        className="relative flex-shrink-0 cursor-pointer"
                        onClick={() => onOpenAlbum?.(song.albumId)}
                      >
                        <img
                          src={song.albumCover}
                          alt={song.title}
                          className="w-20 h-20 rounded-lg object-cover shadow-md group-hover:shadow-xl transition-shadow"
                        />
                        <div className="absolute inset-0 bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <Play className="w-8 h-8 text-white" fill="white" />
                        </div>
                        <Badge className="absolute -top-2 -left-2 bg-secondary text-secondary-foreground border-0 text-xs w-6 h-6 flex items-center justify-center p-0 rounded-full">
                          {index + 1}
                        </Badge>
                      </div>

                      {/* Song Info */}
                      <div className="flex-1 min-w-0">
                        <h3 className="text-foreground font-medium mb-1 truncate group-hover:text-secondary transition-colors">
                          {song.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-1 truncate">
                          {song.artist}
                        </p>
                        <p className="text-xs text-muted-foreground mb-2 truncate">
                          {song.album}
                        </p>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {song.duration}
                          </span>
                          <span className="flex items-center gap-1">
                            <Headphones className="w-3 h-3" />
                            {song.plays}
                          </span>
                        </div>
                      </div>

                      {/* Favourite Button */}
                      <Button
                        size="sm"
                        variant="ghost"
                        className={`h-9 w-9 p-0 flex-shrink-0 ${
                          isFav 
                            ? 'text-accent hover:text-accent/80' 
                            : 'text-muted-foreground hover:text-accent'
                        }`}
                        onClick={(e) => handleToggleFavouriteSong(song, e)}
                      >
                        <Heart className={`w-5 h-5 ${isFav ? 'fill-accent' : ''}`} />
                      </Button>
                    </div>
                  </Card>
                );
              })}
            </div>
          </section>

          {/* What Friends Are Listening To */}
          <section>
            <div className="flex items-center gap-2 mb-4">
              <Headphones className="w-5 h-5 text-chart-3" />
              <h2 className="text-xl text-foreground">Friends Activity</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {friendsListeningToTracks.map((activity) => (
                <Card 
                  key={activity.id}
                  className="p-4 bg-gradient-to-br from-card to-card/50 border-border hover:border-chart-3/50 transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-4">
                    {/* Album Cover */}
                    <div 
                      className="relative flex-shrink-0 cursor-pointer"
                      onClick={() => onOpenAlbum?.()}
                    >
                      <img
                        src={activity.albumCover}
                        alt={activity.trackTitle}
                        className="w-16 h-16 rounded-lg object-cover shadow-md"
                      />
                      <div className="absolute inset-0 bg-black/40 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Play className="w-6 h-6 text-white" fill="white" />
                      </div>
                    </div>

                    {/* Track Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <Avatar className="w-6 h-6 border border-primary">
                          <img src={activity.userAvatar} alt={activity.userName} className="object-cover" />
                        </Avatar>
                        <span className="text-xs text-muted-foreground truncate">
                          <span className="text-foreground font-medium">{activity.userName}</span> is listening
                        </span>
                      </div>
                      <h3 className="text-sm text-foreground font-medium truncate mb-0.5">
                        {activity.trackTitle}
                      </h3>
                      <p className="text-xs text-muted-foreground truncate">
                        {activity.trackArtist}
                      </p>
                    </div>

                    {/* Timestamp */}
                    <div className="flex-shrink-0 text-xs text-muted-foreground">
                      {activity.timestamp}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </section>

          {/* Discovery Tip */}
          <Card className="p-6 bg-gradient-to-br from-primary/10 via-secondary/5 to-accent/10 border-primary/30">
            <div className="flex items-start gap-4">
              <div className="bg-gradient-to-br from-primary/30 to-accent/30 p-3 rounded-lg flex-shrink-0 ring-2 ring-primary/20">
                <Users className="w-6 h-6 text-primary drop-shadow-lg" />
              </div>
              <div>
                <h3 className="text-foreground mb-2">🎯 Discover Your Music Soulmates</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Use AI-powered taste matching to connect with people who share your exact music vibe. Get personalized recommendations and discover hidden gems.
                </p>
                <Button 
                  size="sm" 
                  className="bg-gradient-to-r from-primary via-secondary to-accent hover:from-primary/90 hover:via-secondary/90 hover:to-accent/90 text-white shadow-lg hover:shadow-xl hover:scale-105 transition-all group relative overflow-hidden"
                  onClick={() => {
                    // Navigate to Insights page with taste match tab
                    onNavigate("insights", { insightsTab: "taste" });
                  }}
                >
                  <Users className="w-4 h-4 mr-2 group-hover:rotate-12 transition-transform" />
                  Find Your Taste Matches
                  <Sparkles className="w-3 h-3 ml-2 group-hover:scale-110 transition-transform" />
                </Button>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}