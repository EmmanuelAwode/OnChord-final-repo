import { useState } from "react";
import { Search, UserPlus, UserMinus, Music2, Users, Sparkles, TrendingUp } from "lucide-react";
import { PageHeader } from "./PageHeader";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { motion } from "motion/react";
import { communityUsers } from "../lib/mockData";

interface FindFriendsPageProps {
  onNavigate: (page: string) => void;
  onBack?: () => void;
  canGoBack?: boolean;
}

export function FindFriendsPage({ onNavigate, onBack, canGoBack }: FindFriendsPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [followingState, setFollowingState] = useState<Record<string, boolean>>(() => {
    // Initialize following state from mock data
    const initialState: Record<string, boolean> = {};
    communityUsers.forEach(user => {
      initialState[user.id] = user.isFollowing;
    });
    return initialState;
  });

  const handleToggleFollow = (userId: string) => {
    setFollowingState(prev => ({
      ...prev,
      [userId]: !prev[userId]
    }));
  };

  // Filter users based on search query
  const filteredUsers = communityUsers.filter(user =>
    user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    user.bio.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Categorize users
  const suggestedUsers = communityUsers.filter(user => !followingState[user.id] && user.mutualFriends > 10);
  const topUsers = communityUsers.filter(user => user.mutualFriends >= 18);
  const followsYouBack = communityUsers.filter(user => user.followsYou && !followingState[user.id]);

  const UserCard = ({ user, showMutualFriends = true }: { user: typeof communityUsers[0]; showMutualFriends?: boolean }) => {
    const isFollowing = followingState[user.id];

    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-br from-card to-card/50 rounded-xl p-4 border-2 border-primary/10 hover:border-primary/30 transition-all"
      >
        <div className="flex items-start gap-4">
          {/* Avatar */}
          <button
            onClick={() => onNavigate("profile")}
            className="flex-shrink-0 group"
          >
            <div className="relative">
              <img
                src={user.avatar}
                alt={user.name}
                className="w-16 h-16 rounded-full object-cover ring-2 ring-primary/20 group-hover:ring-primary/50 transition-all"
              />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-gradient-to-br from-secondary to-secondary/80 rounded-full flex items-center justify-center">
                <Music2 className="w-3 h-3 text-white" />
              </div>
            </div>
          </button>

          {/* User Info */}
          <div className="flex-1 min-w-0">
            <button
              onClick={() => onNavigate("profile")}
              className="text-left hover:text-primary transition-colors"
            >
              <h3 className="text-foreground truncate">{user.name}</h3>
              <p className="text-sm text-muted-foreground truncate">{user.username}</p>
            </button>
            <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{user.bio}</p>
            
            {/* Stats */}
            <div className="flex items-center gap-3 mt-2">
              {showMutualFriends && user.mutualFriends > 0 && (
                <div className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Users className="w-3 h-3" />
                  <span>{user.mutualFriends} mutual</span>
                </div>
              )}
              {user.followsYou && (
                <Badge variant="secondary" className="text-xs">
                  Follows you
                </Badge>
              )}
            </div>
          </div>

          {/* Follow Button */}
          <Button
            onClick={() => handleToggleFollow(user.id)}
            variant={isFollowing ? "outline" : "default"}
            size="sm"
            className="flex-shrink-0"
          >
            {isFollowing ? (
              <>
                <UserMinus className="w-4 h-4 mr-1" />
                Following
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4 mr-1" />
                Follow
              </>
            )}
          </Button>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="min-h-screen pb-8">
      <PageHeader
        title="Find Friends"
        subtitle="Connect with other music lovers"
        onBack={onBack}
        canGoBack={canGoBack}
      />

      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search by name, username, or interests..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-12 h-12 bg-card border-2 border-primary/20 focus:border-primary"
          />
        </div>
      </div>

      {/* Tabs */}
      {!searchQuery ? (
        <Tabs defaultValue="suggested" className="w-full">
          <TabsList className="w-full grid grid-cols-3 mb-6">
            <TabsTrigger value="suggested" className="flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              <span className="hidden sm:inline">Suggested</span>
            </TabsTrigger>
            <TabsTrigger value="trending" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              <span className="hidden sm:inline">Trending</span>
            </TabsTrigger>
            <TabsTrigger value="follow-back" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">Follow Back</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="suggested" className="space-y-4">
            <div className="mb-4">
              <h3 className="text-muted-foreground mb-2">Based on your music taste</h3>
            </div>
            {suggestedUsers.length > 0 ? (
              suggestedUsers.map(user => (
                <UserCard key={user.id} user={user} />
              ))
            ) : (
              <div className="text-center py-12">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No suggestions available</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="trending" className="space-y-4">
            <div className="mb-4">
              <h3 className="text-muted-foreground mb-2">Most connected users</h3>
            </div>
            {topUsers.length > 0 ? (
              topUsers.map(user => (
                <UserCard key={user.id} user={user} />
              ))
            ) : (
              <div className="text-center py-12">
                <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No trending users found</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="follow-back" className="space-y-4">
            <div className="mb-4">
              <h3 className="text-muted-foreground mb-2">Users who follow you</h3>
            </div>
            {followsYouBack.length > 0 ? (
              followsYouBack.map(user => (
                <UserCard key={user.id} user={user} />
              ))
            ) : (
              <div className="text-center py-12">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">No users to follow back</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      ) : (
        /* Search Results */
        <div className="space-y-4">
          <div className="mb-4">
            <h3 className="text-muted-foreground">
              {filteredUsers.length} {filteredUsers.length === 1 ? 'result' : 'results'} for "{searchQuery}"
            </h3>
          </div>
          {filteredUsers.length > 0 ? (
            filteredUsers.map(user => (
              <UserCard key={user.id} user={user} />
            ))
          ) : (
            <div className="text-center py-12">
              <Search className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No users found matching "{searchQuery}"</p>
              <p className="text-sm text-muted-foreground mt-2">Try searching by name, username, or music interests</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}