import { useState } from "react";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Avatar } from "./ui/avatar";
import { Search, Music, Disc3, Users, ListMusic, Star } from "lucide-react";
import { albums, reviews, tasteMatches } from "../lib/mockData";
import { EmptyState } from "./EmptyState";

interface SearchPageProps {
  onOpenAlbum?: (albumId: string) => void;
  onNavigate?: (page: string) => void;
}

export function SearchPage({ onOpenAlbum, onNavigate }: SearchPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("all");

  // Filter results based on search query
  const filteredAlbums = albums.filter(
    (album) =>
      album.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      album.artist.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredUsers = tasteMatches.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredReviews = reviews.filter(
    (review) =>
      review.albumTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      review.albumArtist.toLowerCase().includes(searchQuery.toLowerCase()) ||
      review.content.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const hasResults = filteredAlbums.length > 0 || filteredUsers.length > 0 || filteredReviews.length > 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="mb-2">Search</h1>
        <p className="text-muted-foreground">
          Find albums, tracks, users, and playlists
        </p>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Search for albums, artists, users..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-12 h-14 text-lg bg-card border-border"
          autoFocus
        />
      </div>

      {/* Results */}
      {searchQuery.trim() ? (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-card border border-border w-full md:w-auto">
            <TabsTrigger
              value="all"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              All
            </TabsTrigger>
            <TabsTrigger
              value="albums"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Albums ({filteredAlbums.length})
            </TabsTrigger>
            <TabsTrigger
              value="users"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Users ({filteredUsers.length})
            </TabsTrigger>
            <TabsTrigger
              value="reviews"
              className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
            >
              Reviews ({filteredReviews.length})
            </TabsTrigger>
          </TabsList>

          {/* All Results */}
          <TabsContent value="all" className="space-y-6 mt-6">
            {hasResults ? (
              <>
                {/* Albums */}
                {filteredAlbums.length > 0 && (
                  <div>
                    <h3 className="mb-4 flex items-center gap-2">
                      <Disc3 className="w-5 h-5 text-primary" />
                      Albums
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {filteredAlbums.slice(0, 8).map((album) => (
                        <Card
                          key={album.id}
                          className="overflow-hidden bg-card border-border hover:border-primary transition-all cursor-pointer group"
                          onClick={() => onOpenAlbum?.(album.id)}
                        >
                          <img
                            src={album.cover}
                            alt={album.title}
                            className="w-full aspect-square object-cover group-hover:scale-105 transition-transform"
                          />
                          <div className="p-3">
                            <p className="text-foreground truncate">{album.title}</p>
                            <p className="text-sm text-muted-foreground truncate">{album.artist}</p>
                            <div className="flex items-center gap-1 mt-2">
                              <Star className="w-4 h-4 text-primary fill-primary" />
                              <span className="text-sm text-foreground">{album.rating}</span>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Users */}
                {filteredUsers.length > 0 && (
                  <div>
                    <h3 className="mb-4 flex items-center gap-2">
                      <Users className="w-5 h-5 text-secondary" />
                      Users
                    </h3>
                    <div className="grid gap-3">
                      {filteredUsers.slice(0, 5).map((user) => (
                        <Card
                          key={user.id}
                          className="p-4 bg-card border-border hover:border-secondary transition-all"
                        >
                          <div className="flex items-center gap-4">
                            <Avatar className="w-12 h-12">
                              <img src={user.avatar} alt={user.name} className="object-cover" />
                            </Avatar>
                            <div className="flex-1">
                              <p className="text-foreground">{user.name}</p>
                              <p className="text-sm text-muted-foreground">{user.username}</p>
                              <p className="text-xs text-muted-foreground mt-1">
                                {user.compatibility}% match · {user.mutualFriends} mutual friends
                              </p>
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                            >
                              Follow
                            </Button>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}

                {/* Reviews */}
                {filteredReviews.length > 0 && (
                  <div>
                    <h3 className="mb-4 flex items-center gap-2">
                      <Music className="w-5 h-5 text-accent" />
                      Reviews
                    </h3>
                    <div className="grid gap-4">
                      {filteredReviews.slice(0, 5).map((review) => (
                        <Card
                          key={review.id}
                          className="p-4 bg-card border-border hover:border-accent transition-all cursor-pointer"
                          onClick={() => onOpenAlbum?.(review.albumId)}
                        >
                          <div className="flex gap-4">
                            <img
                              src={review.albumCover}
                              alt={review.albumTitle}
                              className="w-16 h-16 md:w-20 md:h-20 rounded-lg object-cover flex-shrink-0"
                            />
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between mb-2">
                                <div className="flex items-center gap-2">
                                  <Avatar className="w-8 h-8">
                                    <img src={review.userAvatar} alt={review.userName} className="object-cover" />
                                  </Avatar>
                                  <div>
                                    <p className="text-sm text-foreground">{review.userName}</p>
                                    <p className="text-xs text-muted-foreground">
                                      {review.albumTitle} · {review.albumArtist}
                                    </p>
                                  </div>
                                </div>
                                <Badge variant="secondary" className="bg-primary/20 text-primary flex items-center gap-1">
                                  <Star className="w-3 h-3 fill-primary" />
                                  {review.rating}
                                </Badge>
                              </div>
                              <p className="text-sm text-foreground line-clamp-2">{review.content}</p>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <EmptyState
                icon={Search}
                title="No Results Found"
                description={`No results found for "${searchQuery}". Try searching for different keywords.`}
              />
            )}
          </TabsContent>

          {/* Albums Tab */}
          <TabsContent value="albums" className="mt-6">
            {filteredAlbums.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredAlbums.map((album) => (
                  <Card
                    key={album.id}
                    className="overflow-hidden bg-card border-border hover:border-primary transition-all cursor-pointer group"
                    onClick={() => onOpenAlbum?.(album.id)}
                  >
                    <img
                      src={album.cover}
                      alt={album.title}
                      className="w-full aspect-square object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="p-3">
                      <p className="text-foreground truncate">{album.title}</p>
                      <p className="text-sm text-muted-foreground truncate">{album.artist}</p>
                      <div className="flex items-center gap-1 mt-2">
                        <Star className="w-4 h-4 text-primary fill-primary" />
                        <span className="text-sm text-foreground">{album.rating}</span>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <EmptyState
                icon={Disc3}
                title="No Albums Found"
                description={`No albums found for "${searchQuery}".`}
              />
            )}
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="mt-6">
            {filteredUsers.length > 0 ? (
              <div className="grid gap-3">
                {filteredUsers.map((user) => (
                  <Card
                    key={user.id}
                    className="p-4 bg-card border-border hover:border-secondary transition-all"
                  >
                    <div className="flex items-center gap-4">
                      <Avatar className="w-12 h-12">
                        <img src={user.avatar} alt={user.name} className="object-cover" />
                      </Avatar>
                      <div className="flex-1">
                        <p className="text-foreground">{user.name}</p>
                        <p className="text-sm text-muted-foreground">{user.username}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {user.compatibility}% match · {user.mutualFriends} mutual friends
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                      >
                        Follow
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <EmptyState
                icon={Users}
                title="No Users Found"
                description={`No users found for "${searchQuery}".`}
              />
            )}
          </TabsContent>

          {/* Reviews Tab */}
          <TabsContent value="reviews" className="mt-6">
            {filteredReviews.length > 0 ? (
              <div className="grid gap-4">
                {filteredReviews.map((review) => (
                  <Card
                    key={review.id}
                    className="p-4 bg-card border-border hover:border-accent transition-all cursor-pointer"
                    onClick={() => onOpenAlbum?.(review.albumId)}
                  >
                    <div className="flex gap-4">
                      <img
                        src={review.albumCover}
                        alt={review.albumTitle}
                        className="w-16 h-16 md:w-20 md:h-20 rounded-lg object-cover flex-shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <Avatar className="w-8 h-8">
                              <img src={review.userAvatar} alt={review.userName} className="object-cover" />
                            </Avatar>
                            <div>
                              <p className="text-sm text-foreground">{review.userName}</p>
                              <p className="text-xs text-muted-foreground">
                                {review.albumTitle} · {review.albumArtist}
                              </p>
                            </div>
                          </div>
                          <Badge variant="secondary" className="bg-primary/20 text-primary flex items-center gap-1">
                            <Star className="w-3 h-3 fill-primary" />
                            {review.rating}
                          </Badge>
                        </div>
                        <p className="text-sm text-foreground">{review.content}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <EmptyState
                icon={Music}
                title="No Reviews Found"
                description={`No reviews found for "${searchQuery}".`}
              />
            )}
          </TabsContent>
        </Tabs>
      ) : (
        <div className="py-12">
          <EmptyState
            icon={Search}
            title="Start Searching"
            description="Search for your favorite albums, artists, tracks, or find new music friends."
          />
        </div>
      )}
    </div>
  );
}
