import { useState, useMemo } from "react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Avatar } from "./ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Input } from "./ui/input";
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Legend } from "recharts";
import { Sparkles, Users, TrendingUp, Music, UserPlus, Search, X } from "lucide-react";
import { musicPersonality, tasteMatches } from "../lib/mockData";

export function MusicPersonalityPage() {
  const [selectedFriend, setSelectedFriend] = useState(tasteMatches[0]);
  const [searchQuery, setSearchQuery] = useState("");

  const personalityData = [
    {
      attribute: "Energy",
      you: musicPersonality.current.energy,
      friend: musicPersonality.friend.energy,
    },
    {
      attribute: "Danceability",
      you: musicPersonality.current.danceability,
      friend: musicPersonality.friend.danceability,
    },
    {
      attribute: "Valence",
      you: musicPersonality.current.valence,
      friend: musicPersonality.friend.valence,
    },
    {
      attribute: "Acousticness",
      you: musicPersonality.current.acousticness,
      friend: musicPersonality.friend.acousticness,
    },
    {
      attribute: "Instrumental",
      you: musicPersonality.current.instrumentalness,
      friend: musicPersonality.friend.instrumentalness,
    },
  ];

  const singlePersonalityData = personalityData.map((item) => ({
    attribute: item.attribute,
    value: item.you,
  }));

  // Filter friends based on search query
  const filteredFriends = useMemo(() => {
    if (!searchQuery.trim()) return tasteMatches;
    
    const query = searchQuery.toLowerCase();
    return tasteMatches.filter(
      (friend) =>
        friend.name.toLowerCase().includes(query) ||
        friend.username.toLowerCase().includes(query) ||
        friend.commonArtists.some((artist) => artist.toLowerCase().includes(query))
    );
  }, [searchQuery]);

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex justify-center mb-4">
          <div className="bg-primary/10 p-4 rounded-full">
            <Sparkles className="w-8 h-8 text-primary" />
          </div>
        </div>
        <h1 className="text-3xl text-foreground">Your Music Personality</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Advanced ML analysis of your listening patterns reveals your unique musical DNA
        </p>
      </div>

      {/* Personality Overview */}
      <Card className="p-8 bg-gradient-to-br from-primary/10 to-secondary/10 border-primary/30">
        <div className="text-center mb-6">
          <h2 className="text-2xl text-foreground mb-2">The Chill Explorer</h2>
          <p className="text-muted-foreground">
            Your personality type based on listening habits
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-3">
          <Badge className="bg-primary/20 text-primary border-0 px-4 py-2">
            High Valence
          </Badge>
          <Badge className="bg-secondary/20 text-secondary border-0 px-4 py-2">
            Moderate Energy
          </Badge>
          <Badge className="bg-chart-3/20 text-chart-3 border-0 px-4 py-2">
            Eclectic Taste
          </Badge>
        </div>
      </Card>

      {/* Tabs for Different Views */}
      <Tabs defaultValue="single" className="w-full">
        <TabsList className="bg-card border border-border w-full md:w-auto">
          <TabsTrigger
            value="single"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            <Music className="w-4 h-4 mr-2" />
            Your Profile
          </TabsTrigger>
          <TabsTrigger
            value="compare"
            className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
          >
            <Users className="w-4 h-4 mr-2" />
            Compare with Friend
          </TabsTrigger>
        </TabsList>

        {/* Single Profile */}
        <TabsContent value="single" className="mt-6">
          <Card className="p-8 bg-card border-border">
            <ResponsiveContainer width="100%" height={400}>
              <RadarChart data={singlePersonalityData}>
                <PolarGrid stroke="#4C566A" />
                <PolarAngleAxis
                  dataKey="attribute"
                  tick={{ fill: "#9CA3AF", fontSize: 12 }}
                />
                <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: "#9CA3AF" }} />
                <Radar
                  name="Your Profile"
                  dataKey="value"
                  stroke="#A78BFA"
                  fill="#A78BFA"
                  fillOpacity={0.6}
                />
                <Legend wrapperStyle={{ color: "#F3F4F6" }} />
              </RadarChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>

        {/* Comparison */}
        <TabsContent value="compare" className="mt-6 space-y-6">
          {/* Friend Selector with Search */}
          <Card className="p-6 bg-card border-border shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-foreground">Compare With</h3>
              <Badge className="bg-primary/20 text-primary border-0">
                {filteredFriends.length} {filteredFriends.length === 1 ? 'Friend' : 'Friends'}
              </Badge>
            </div>
            
            {/* Search Bar */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
              <Input
                type="text"
                placeholder="Search by name, username, or artist..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-10 bg-background/50 border-2 border-border focus:border-primary transition-colors"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Friends Grid */}
            {filteredFriends.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[400px] overflow-y-auto pr-2 nav-scroll">
                {filteredFriends.map((friend) => (
                  <button
                    key={friend.id}
                    onClick={() => {
                      setSelectedFriend(friend);
                      setSearchQuery("");
                    }}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      selectedFriend.id === friend.id
                        ? "border-primary bg-gradient-to-br from-primary/20 to-primary/10 shadow-md"
                        : "border-border hover:border-primary/50 bg-background/50 hover:bg-background"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Avatar className="w-12 h-12 border-2 border-primary shrink-0">
                        <img src={friend.avatar} alt={friend.name} className="object-cover" />
                      </Avatar>
                      <div className="text-left flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{friend.name}</p>
                        <p className="text-xs text-muted-foreground truncate">{friend.username}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <Badge className="bg-secondary/20 text-secondary border-0 text-xs">
                            {friend.compatibility}%
                          </Badge>
                          {friend.mutualFriends > 0 && (
                            <span className="text-xs text-muted-foreground">
                              {friend.mutualFriends} mutual
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    {/* Common Artists Preview */}
                    <div className="mt-2 pt-2 border-t border-border/50">
                      <p className="text-xs text-muted-foreground mb-1">Common artists:</p>
                      <div className="flex flex-wrap gap-1">
                        {friend.commonArtists.slice(0, 2).map((artist, idx) => (
                          <span key={idx} className="text-xs bg-muted/50 px-2 py-0.5 rounded-full text-muted-foreground">
                            {artist}
                          </span>
                        ))}
                        {friend.commonArtists.length > 2 && (
                          <span className="text-xs text-primary">
                            +{friend.commonArtists.length - 2}
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <Users className="w-12 h-12 text-muted-foreground mx-auto mb-3 opacity-50" />
                <p className="text-muted-foreground">No friends found</p>
                <p className="text-sm text-muted-foreground mt-1">Try a different search term</p>
              </div>
            )}
          </Card>

          {/* Side-by-Side Comparison */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Your Chart */}
            <Card className="p-6 bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20 shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <Avatar className="w-10 h-10 border-2 border-primary">
                  <img src="https://images.unsplash.com/photo-1658874379930-13ab23191da6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400" alt="You" className="object-cover" />
                </Avatar>
                <div>
                  <p className="text-foreground font-medium">Your Profile</p>
                  <p className="text-xs text-muted-foreground">The Chill Explorer</p>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={singlePersonalityData}>
                  <PolarGrid stroke="#4C566A" />
                  <PolarAngleAxis
                    dataKey="attribute"
                    tick={{ fill: "#9CA3AF", fontSize: 10 }}
                  />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: "#9CA3AF" }} />
                  <Radar
                    name="You"
                    dataKey="value"
                    stroke="#A78BFA"
                    fill="#A78BFA"
                    fillOpacity={0.6}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </Card>

            {/* Friend's Chart */}
            <Card className="p-6 bg-gradient-to-br from-secondary/10 to-secondary/5 border-secondary/20 shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <Avatar className="w-10 h-10 border-2 border-secondary">
                  <img src={selectedFriend.avatar} alt={selectedFriend.name} className="object-cover" />
                </Avatar>
                <div>
                  <p className="text-foreground font-medium">{selectedFriend.name}</p>
                  <p className="text-xs text-muted-foreground">The Dance Enthusiast</p>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={300}>
                <RadarChart data={personalityData}>
                  <PolarGrid stroke="#4C566A" />
                  <PolarAngleAxis
                    dataKey="attribute"
                    tick={{ fill: "#9CA3AF", fontSize: 10 }}
                  />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: "#9CA3AF" }} />
                  <Radar
                    name={selectedFriend.name}
                    dataKey="friend"
                    stroke="#34D399"
                    fill="#34D399"
                    fillOpacity={0.6}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Overlay Comparison */}
          <Card className="p-8 bg-card border-border shadow-lg">
            <div className="mb-6 text-center">
              <h3 className="text-lg text-foreground mb-2">Combined Comparison</h3>
              <p className="text-sm text-muted-foreground">
                See how your music personalities overlap
              </p>
            </div>
            <div className="mb-4 flex items-center justify-center gap-6">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-primary rounded-full shadow-md" />
                <span className="text-sm text-foreground">You</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-secondary rounded-full shadow-md" />
                <span className="text-sm text-foreground">{selectedFriend.name}</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={400}>
              <RadarChart data={personalityData}>
                <PolarGrid stroke="#4C566A" />
                <PolarAngleAxis
                  dataKey="attribute"
                  tick={{ fill: "#9CA3AF", fontSize: 12 }}
                />
                <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: "#9CA3AF" }} />
                <Radar
                  name="You"
                  dataKey="you"
                  stroke="#A78BFA"
                  fill="#A78BFA"
                  fillOpacity={0.5}
                  strokeWidth={2}
                />
                <Radar
                  name={selectedFriend.name}
                  dataKey="friend"
                  stroke="#34D399"
                  fill="#34D399"
                  fillOpacity={0.5}
                  strokeWidth={2}
                />
                <Legend wrapperStyle={{ color: "#F3F4F6" }} />
              </RadarChart>
            </ResponsiveContainer>

            {/* Compatibility Score */}
            <div className="mt-6 p-4 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg border border-primary/20">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Users className="w-5 h-5 text-primary" />
                  <span className="text-foreground">Musical Compatibility</span>
                </div>
                <Badge className="bg-primary text-primary-foreground text-lg px-4 py-1">
                  {selectedFriend.compatibility}%
                </Badge>
              </div>
            </div>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Personality Breakdown */}
      <div className="grid md:grid-cols-2 gap-4">
        <Card className="p-6 bg-card border-border">
          <div className="flex gap-4">
            <div className="bg-primary/20 p-3 rounded-lg h-fit">
              <TrendingUp className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="text-foreground mb-2">Energy Level: Moderate</h3>
              <p className="text-sm text-muted-foreground mb-3">
                You prefer music with balanced energy - not too intense, but not too mellow either.
              </p>
              <Badge className="bg-primary/20 text-primary border-0">65/100</Badge>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-card border-border">
          <div className="flex gap-4">
            <div className="bg-secondary/20 p-3 rounded-lg h-fit">
              <Music className="w-6 h-6 text-secondary" />
            </div>
            <div>
              <h3 className="text-foreground mb-2">Danceability: High</h3>
              <p className="text-sm text-muted-foreground mb-3">
                You gravitate toward tracks with strong rhythms and grooves that make you want to move.
              </p>
              <Badge className="bg-secondary/20 text-secondary border-0">72/100</Badge>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-card border-border">
          <div className="flex gap-4">
            <div className="bg-chart-3/20 p-3 rounded-lg h-fit">
              <Sparkles className="w-6 h-6 text-chart-3" />
            </div>
            <div>
              <h3 className="text-foreground mb-2">Valence: Positive</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Your playlists lean toward uplifting and cheerful music that boosts your mood.
              </p>
              <Badge className="bg-chart-3/20 text-chart-3 border-0">58/100</Badge>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-card border-border">
          <div className="flex gap-4">
            <div className="bg-chart-4/20 p-3 rounded-lg h-fit">
              <Music className="w-6 h-6 text-chart-4" />
            </div>
            <div>
              <h3 className="text-foreground mb-2">Acousticness: Balanced</h3>
              <p className="text-sm text-muted-foreground mb-3">
                You enjoy a mix of acoustic and electronic sounds, showing diverse taste.
              </p>
              <Badge className="bg-chart-4/20 text-chart-4 border-0">45/100</Badge>
            </div>
          </div>
        </Card>
      </div>

      {/* How It Works */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-foreground mb-3">How We Calculate Your Personality</h3>
        <p className="text-muted-foreground text-sm mb-4">
          Our machine learning model analyzes various audio features from your listening history:
        </p>
        <div className="grid md:grid-cols-2 gap-3">
          <div className="flex items-start gap-2 text-sm">
            <span className="text-primary">•</span>
            <span className="text-muted-foreground">
              <span className="text-foreground">Energy:</span> Overall intensity and activity level
            </span>
          </div>
          <div className="flex items-start gap-2 text-sm">
            <span className="text-primary">•</span>
            <span className="text-muted-foreground">
              <span className="text-foreground">Danceability:</span> Rhythm, tempo, and beat strength
            </span>
          </div>
          <div className="flex items-start gap-2 text-sm">
            <span className="text-primary">•</span>
            <span className="text-muted-foreground">
              <span className="text-foreground">Valence:</span> Musical positiveness and mood
            </span>
          </div>
          <div className="flex items-start gap-2 text-sm">
            <span className="text-primary">•</span>
            <span className="text-muted-foreground">
              <span className="text-foreground">Acousticness:</span> Presence of acoustic instruments
            </span>
          </div>
        </div>
      </Card>
    </div>
  );
}