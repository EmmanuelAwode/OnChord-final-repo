import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { ScrollArea } from "./ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { X, Search, Plus, Globe, Lock, Users, Music, Disc } from "lucide-react";
import { albums, trendingSongs } from "../lib/mockData";
import { toast } from "sonner@2.0.3";

interface CreateListModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreateList: (list: {
    title: string;
    description: string;
    visibility: "public" | "private" | "friends";
    albumIds: string[];
    songIds: string[];
  }) => void;
}

export function CreateListModal({ isOpen, onClose, onCreateList }: CreateListModalProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [visibility, setVisibility] = useState<"public" | "private" | "friends">("public");
  const [selectedAlbums, setSelectedAlbums] = useState<string[]>([]);
  const [selectedSongs, setSelectedSongs] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [contentType, setContentType] = useState<"albums" | "songs">("albums");

  // Filter albums based on search query
  const filteredAlbums = albums.filter(album => 
    album.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    album.artist.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Filter songs based on search query
  const filteredSongs = trendingSongs.filter(song => 
    song.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    song.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
    song.album.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleAlbum = (albumId: string) => {
    setSelectedAlbums(prev => 
      prev.includes(albumId) 
        ? prev.filter(id => id !== albumId)
        : [...prev, albumId]
    );
  };

  const toggleSong = (songId: string) => {
    setSelectedSongs(prev => 
      prev.includes(songId) 
        ? prev.filter(id => id !== songId)
        : [...prev, songId]
    );
  };

  const handleCreate = () => {
    if (!title.trim()) {
      toast.error("Please enter a list title");
      return;
    }

    if (selectedAlbums.length === 0 && selectedSongs.length === 0) {
      toast.error("Please add at least one album or song to your list");
      return;
    }

    onCreateList({
      title: title.trim(),
      description: description.trim(),
      visibility,
      albumIds: selectedAlbums,
      songIds: selectedSongs,
    });

    // Reset form
    setTitle("");
    setDescription("");
    setVisibility("public");
    setSelectedAlbums([]);
    setSelectedSongs([]);
    setSearchQuery("");
    
    toast.success("List created successfully!");
    onClose();
  };

  const handleClose = () => {
    // Reset form when closing
    setTitle("");
    setDescription("");
    setVisibility("public");
    setSelectedAlbums([]);
    setSelectedSongs([]);
    setSearchQuery("");
    onClose();
  };

  const visibilityOptions = [
    {
      value: "public" as const,
      label: "Public",
      icon: Globe,
      description: "Anyone can see this list",
    },
    {
      value: "private" as const,
      label: "Private",
      icon: Lock,
      description: "Only you can see this list",
    },
    {
      value: "friends" as const,
      label: "Friends Only",
      icon: Users,
      description: "Only your friends can see this list",
    },
  ];

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] p-0 gap-0 overflow-hidden">
        <DialogHeader className="p-6 pb-4 border-b border-border">
          <DialogTitle>Create New List</DialogTitle>
          <DialogDescription>
            Name your list, add albums or songs, and choose who can see it
          </DialogDescription>
        </DialogHeader>

        <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6 space-y-6">
          {/* List Details */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="list-title" className="text-foreground mb-2 block">
                List Title *
              </Label>
              <Input
                id="list-title"
                placeholder="e.g., Summer Vibes 2024"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="bg-background border-border text-foreground"
                maxLength={60}
              />
              <p className="text-xs text-muted-foreground mt-1">
                {title.length}/60 characters
              </p>
            </div>

            <div>
              <Label htmlFor="list-description" className="text-foreground mb-2 block">
                Description (Optional)
              </Label>
              <Textarea
                id="list-description"
                placeholder="Describe what this list is about..."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="bg-background border-border text-foreground resize-none min-h-[80px]"
                maxLength={200}
              />
              <p className="text-xs text-muted-foreground mt-1">
                {description.length}/200 characters
              </p>
            </div>
          </div>

          {/* Visibility */}
          <div>
            <Label className="text-foreground mb-3 block">Visibility</Label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {visibilityOptions.map((option) => {
                const Icon = option.icon;
                const isSelected = visibility === option.value;
                return (
                  <button
                    key={option.value}
                    onClick={() => setVisibility(option.value)}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      isSelected
                        ? "border-primary bg-primary/10"
                        : "border-border bg-card hover:border-primary/50"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <Icon className={`w-4 h-4 ${isSelected ? "text-primary" : "text-muted-foreground"}`} />
                      <span className={`${isSelected ? "text-foreground" : "text-foreground"}`}>
                        {option.label}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground">{option.description}</p>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Add Content */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <Label className="text-foreground">List Content *</Label>
              <Badge variant="outline" className="border-primary text-primary">
                {selectedAlbums.length} albums, {selectedSongs.length} songs
              </Badge>
            </div>

            {/* Content Type Tabs */}
            <Tabs value={contentType} onValueChange={(v) => setContentType(v as "albums" | "songs")} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="albums" className="flex items-center gap-2">
                  <Disc className="w-4 h-4" />
                  Albums
                </TabsTrigger>
                <TabsTrigger value="songs" className="flex items-center gap-2">
                  <Music className="w-4 h-4" />
                  Songs
                </TabsTrigger>
              </TabsList>

              {/* Search */}
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder={`Search ${contentType}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-10 bg-background border-border text-foreground"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              <TabsContent value="albums" className="mt-0">
                {/* Selected Albums Preview */}
                {selectedAlbums.length > 0 && (
                  <div className="mb-4">
                    <p className="text-sm text-muted-foreground mb-2">Selected Albums:</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedAlbums.map(albumId => {
                        const album = albums.find(a => a.id === albumId);
                        if (!album) return null;
                        return (
                          <Badge
                            key={albumId}
                            className="bg-primary/20 text-primary border-0 pr-1 gap-1"
                          >
                            <span className="truncate max-w-[150px]">{album.title}</span>
                            <button
                              onClick={() => toggleAlbum(albumId)}
                              className="hover:bg-primary/30 rounded-full p-0.5 transition-colors"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </Badge>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Album Grid */}
                <ScrollArea className="h-[400px] rounded-lg border border-border bg-muted/20 p-4">
                  {filteredAlbums.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                      {filteredAlbums.map((album) => {
                        const isSelected = selectedAlbums.includes(album.id);
                        return (
                          <button
                            key={album.id}
                            onClick={() => toggleAlbum(album.id)}
                            className={`group relative rounded-lg overflow-hidden transition-all ${
                              isSelected
                                ? "ring-2 ring-primary ring-offset-2 ring-offset-background"
                                : "hover:ring-2 hover:ring-primary/50"
                            }`}
                          >
                            <img
                              src={album.cover}
                              alt={album.title}
                              className="w-full aspect-square object-cover"
                            />
                            <div className={`absolute inset-0 flex items-center justify-center transition-all ${
                              isSelected
                                ? "bg-primary/80"
                                : "bg-black/60 opacity-0 group-hover:opacity-100"
                            }`}>
                              {isSelected ? (
                                <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center">
                                  <Plus className="w-5 h-5 text-primary rotate-45" />
                                </div>
                              ) : (
                                <Plus className="w-8 h-8 text-white" />
                              )}
                            </div>
                            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2">
                              <p className="text-white text-xs line-clamp-1">{album.title}</p>
                              <p className="text-white/70 text-xs line-clamp-1">{album.artist}</p>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-[300px] text-center">
                      <Disc className="w-12 h-12 text-muted-foreground mb-3" />
                      <p className="text-foreground mb-1">No albums found</p>
                      <p className="text-sm text-muted-foreground">
                        Try a different search term
                      </p>
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>

              <TabsContent value="songs" className="mt-0">
                {/* Selected Songs Preview */}
                {selectedSongs.length > 0 && (
                  <div className="mb-4">
                    <p className="text-sm text-muted-foreground mb-2">Selected Songs:</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedSongs.map(songId => {
                        const song = trendingSongs.find(s => s.id === songId);
                        if (!song) return null;
                        return (
                          <Badge
                            key={songId}
                            className="bg-secondary/20 text-secondary border-0 pr-1 gap-1"
                          >
                            <span className="truncate max-w-[150px]">{song.title}</span>
                            <button
                              onClick={() => toggleSong(songId)}
                              className="hover:bg-secondary/30 rounded-full p-0.5 transition-colors"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </Badge>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Song List */}
                <ScrollArea className="h-[400px] rounded-lg border border-border bg-muted/20 p-4">
                  {filteredSongs.length > 0 ? (
                    <div className="space-y-2">
                      {filteredSongs.map((song) => {
                        const isSelected = selectedSongs.includes(song.id);
                        return (
                          <button
                            key={song.id}
                            onClick={() => toggleSong(song.id)}
                            className={`w-full p-3 rounded-lg transition-all text-left flex items-center gap-3 ${
                              isSelected
                                ? "bg-secondary/20 border-2 border-secondary"
                                : "bg-card border-2 border-border hover:border-secondary/50"
                            }`}
                          >
                            <img
                              src={song.cover}
                              alt={song.title}
                              className="w-12 h-12 rounded object-cover flex-shrink-0"
                            />
                            <div className="flex-1 min-w-0">
                              <p className="text-foreground truncate text-sm">{song.title}</p>
                              <p className="text-muted-foreground truncate text-xs">{song.artist}</p>
                            </div>
                            <div className="text-xs text-muted-foreground flex-shrink-0">
                              {song.duration}
                            </div>
                            {isSelected && (
                              <div className="w-6 h-6 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                                <Plus className="w-4 h-4 text-white rotate-45" />
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-[300px] text-center">
                      <Music className="w-12 h-12 text-muted-foreground mb-3" />
                      <p className="text-foreground mb-1">No songs found</p>
                      <p className="text-sm text-muted-foreground">
                        Try a different search term
                      </p>
                    </div>
                  )}
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border flex items-center justify-end gap-4 bg-card">
          <Button
            variant="outline"
            onClick={handleClose}
            className="px-8 py-5 border-primary/30 bg-primary/5 hover:bg-primary/10 text-foreground rounded-lg"
          >
            Cancel
          </Button>
          <Button
            onClick={handleCreate}
            className="px-8 py-5 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground shadow-lg rounded-lg"
          >
            Create List
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
