import { useState } from "react";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Button } from "./ui/button";
import { Avatar } from "./ui/avatar";
import { BackButton } from "./BackButton";
import { Switch } from "./ui/switch";
import { Label } from "./ui/label";
import { 
  User, 
  Camera, 
  Mail, 
  MapPin, 
  Link as LinkIcon, 
  Music,
  CheckCircle2,
  XCircle
} from "lucide-react";
import { currentUser } from "../lib/mockData";

interface EditProfilePageProps {
  onNavigate?: (page: string) => void;
  onBack?: () => void;
  canGoBack?: boolean;
}

export function EditProfilePage({ onNavigate, onBack, canGoBack }: EditProfilePageProps) {
  const [name, setName] = useState(currentUser.name);
  const [username, setUsername] = useState(currentUser.username.replace('@', ''));
  const [bio, setBio] = useState(currentUser.bio);
  const [location, setLocation] = useState("San Francisco, CA");
  const [website, setWebsite] = useState("onchord.music");
  const [spotifyConnected, setSpotifyConnected] = useState(true);
  const [appleMusicConnected, setAppleMusicConnected] = useState(false);
  const [publicProfile, setPublicProfile] = useState(true);

  const handleSave = () => {
    // Save profile changes
    if (onBack) {
      onBack();
    } else {
      onNavigate?.("your-space");
    }
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-4xl mx-auto">
      <BackButton onClick={onBack || (() => onNavigate?.("your-space"))} label={canGoBack ? "Back" : "Back to My Space"} />

      {/* Header */}
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center shadow-lg">
          <User className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-3xl text-foreground">Edit Profile</h1>
          <p className="text-muted-foreground">Customize your OnChord presence</p>
        </div>
      </div>

      {/* Profile Picture */}
      <Card className="p-6 bg-card border-border shadow-lg">
        <h3 className="text-lg text-foreground mb-4">Profile Picture</h3>
        <div className="flex items-center gap-6">
          <div className="relative group">
            <Avatar className="w-24 h-24 border-4 border-primary shadow-lg">
              <img src={currentUser.avatar} alt={currentUser.name} className="object-cover" />
            </Avatar>
            <button className="absolute inset-0 bg-black/60 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition">
              <Camera className="w-6 h-6 text-white" />
            </button>
          </div>
          <div className="space-y-2">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">
              <Camera className="w-4 h-4 mr-2" />
              Upload New Photo
            </Button>
            <p className="text-xs text-muted-foreground">
              JPG, PNG or GIF. Max size 2MB.
            </p>
          </div>
        </div>
      </Card>

      {/* Basic Information */}
      <Card className="p-6 bg-card border-border shadow-lg">
        <h3 className="text-lg text-foreground mb-4">Basic Information</h3>
        <div className="space-y-4">
          <div>
            <Label htmlFor="name">Display Name</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Your name"
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="username">Username</Label>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-muted-foreground">@</span>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))}
                placeholder="username"
                className="flex-1"
              />
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Letters, numbers, and underscores only
            </p>
          </div>

          <div>
            <Label htmlFor="bio">Bio</Label>
            <Textarea
              id="bio"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell us about your musical journey..."
              className="mt-1 min-h-[100px]"
              maxLength={160}
            />
            <p className="text-xs text-muted-foreground mt-1">
              {bio.length}/160 characters
            </p>
          </div>

          <div>
            <Label htmlFor="location">Location</Label>
            <div className="relative mt-1">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="location"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="City, Country"
                className="pl-10"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="website">Website</Label>
            <div className="relative mt-1">
              <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                id="website"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                placeholder="yourwebsite.com"
                className="pl-10"
              />
            </div>
          </div>
        </div>
      </Card>

      {/* Connected Accounts */}
      <Card className="p-6 bg-card border-border shadow-lg">
        <h3 className="text-lg text-foreground mb-4">Connected Accounts</h3>
        <div className="space-y-4">
          {/* Spotify */}
          <div className="flex items-center justify-between p-4 bg-background rounded-lg border border-border">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1DB954] to-[#1aa34a] rounded-lg flex items-center justify-center shadow-md">
                <Music className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-foreground font-medium">Spotify</p>
                <p className="text-xs text-muted-foreground">
                  {spotifyConnected ? "Connected" : "Not connected"}
                </p>
              </div>
            </div>
            {spotifyConnected ? (
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-secondary" />
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setSpotifyConnected(false)}
                  className="border-destructive text-destructive hover:bg-destructive hover:text-white"
                >
                  Disconnect
                </Button>
              </div>
            ) : (
              <Button 
                size="sm"
                onClick={() => setSpotifyConnected(true)}
                className="bg-[#1DB954] hover:bg-[#1aa34a] text-white"
              >
                Connect
              </Button>
            )}
          </div>

          {/* Apple Music */}
          <div className="flex items-center justify-between p-4 bg-background rounded-lg border border-border">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#FA233B] to-[#d91e31] rounded-lg flex items-center justify-center shadow-md">
                <Music className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-foreground font-medium">Apple Music</p>
                <p className="text-xs text-muted-foreground">
                  {appleMusicConnected ? "Connected" : "Not connected"}
                </p>
              </div>
            </div>
            {appleMusicConnected ? (
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-secondary" />
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setAppleMusicConnected(false)}
                  className="border-destructive text-destructive hover:bg-destructive hover:text-white"
                >
                  Disconnect
                </Button>
              </div>
            ) : (
              <Button 
                size="sm"
                onClick={() => setAppleMusicConnected(true)}
                className="bg-[#FA233B] hover:bg-[#d91e31] text-white"
              >
                Connect
              </Button>
            )}
          </div>

          <div className="flex items-center gap-2 p-3 bg-secondary/10 rounded-lg border border-secondary/20">
            <Mail className="w-4 h-4 text-secondary" />
            <p className="text-sm text-muted-foreground">
              Connect your music accounts to unlock personalized insights and seamless playlist syncing
            </p>
          </div>
        </div>
      </Card>

      {/* Privacy Settings */}
      <Card className="p-6 bg-card border-border shadow-lg">
        <h3 className="text-lg text-foreground mb-4">Privacy</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="public-profile">Public Profile</Label>
              <p className="text-sm text-muted-foreground">
                Allow others to view your profile and reviews
              </p>
            </div>
            <Switch
              id="public-profile"
              checked={publicProfile}
              onCheckedChange={setPublicProfile}
            />
          </div>
        </div>
      </Card>

      {/* Action Buttons */}
      <div className="flex gap-3 pb-8">
        <Button
          onClick={handleSave}
          className="flex-1 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground shadow-lg"
        >
          Save Changes
        </Button>
        <Button
          variant="outline"
          onClick={onBack || (() => onNavigate?.("your-space"))}
          className="border-border"
        >
          Cancel
        </Button>
      </div>
    </div>
  );
}
