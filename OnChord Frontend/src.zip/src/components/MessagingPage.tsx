import { useState, useEffect, useRef } from "react";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Avatar } from "./ui/avatar";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { BackButton } from "./BackButton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "./ui/dialog";
import { Send, Music, Share2, MoreVertical, Image, Smile, X, Search, Plus } from "lucide-react";
import { messages, chatHistories, connections, albums, currentUser } from "../lib/mockData";
import { toast } from "sonner@2.0.3";

interface MessagingPageProps {
  onBack?: () => void;
  canGoBack?: boolean;
}

export function MessagingPage({ onBack, canGoBack }: MessagingPageProps) {
  const [selectedChat, setSelectedChat] = useState(messages[0]);
  const [messageInput, setMessageInput] = useState("");
  const [conversationMessages, setConversationMessages] = useState(chatHistories[messages[0].id] || []);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [showGifModal, setShowGifModal] = useState(false);
  const [showShareTrackModal, setShowShareTrackModal] = useState(false);
  const [gifSearchQuery, setGifSearchQuery] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);

  // Scroll to bottom when messages change
  const scrollToBottom = (smooth = true) => {
    if (messagesContainerRef.current) {
      const scrollHeight = messagesContainerRef.current.scrollHeight;
      messagesContainerRef.current.scrollTo({
        top: scrollHeight,
        behavior: smooth ? "smooth" : "auto"
      });
    }
  };

  // Update messages when chat changes
  useEffect(() => {
    setConversationMessages(chatHistories[selectedChat.id] || []);
    // Scroll to bottom immediately when switching chats (no animation)
    setTimeout(() => scrollToBottom(false), 50);
  }, [selectedChat]);

  // Scroll to bottom when new messages are added
  useEffect(() => {
    scrollToBottom(true);
  }, [conversationMessages]);

  // Mock GIF suggestions
  const gifSuggestions = [
    {
      id: "gif1",
      url: "https://media.giphy.com/media/l0HlNQ03J5JxX6lva/giphy.gif",
      title: "Dancing"
    },
    {
      id: "gif2",
      url: "https://media.giphy.com/media/l378khQxt68syiNJm/giphy.gif",
      title: "Music Vibes"
    },
    {
      id: "gif3",
      url: "https://media.giphy.com/media/xUPGcC0R9QjyxkPnS8/giphy.gif",
      title: "Fire"
    },
    {
      id: "gif4",
      url: "https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif",
      title: "Party"
    },
    {
      id: "gif5",
      url: "https://media.giphy.com/media/26u4cqiYI30juCOGY/giphy.gif",
      title: "Thumbs Up"
    },
    {
      id: "gif6",
      url: "https://media.giphy.com/media/g9582DNuQppxC/giphy.gif",
      title: "Cool"
    },
  ];

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error("Please select an image file");
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Image must be less than 5MB");
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
        toast.success("Image selected! Click send to share it.");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSendMessage = () => {
    if (!messageInput.trim() && !selectedImage) return;
    
    const newMsg = {
      id: `msg${Date.now()}`,
      content: messageInput,
      timestamp: "Just now",
      isOwn: true,
      type: selectedImage ? "image" : "text",
      imageUrl: selectedImage || undefined,
    };
    
    setConversationMessages([...conversationMessages, newMsg]);
    setMessageInput("");
    setSelectedImage(null);
  };

  const handleSendGif = (gifUrl: string) => {
    const newMsg = {
      id: `msg${Date.now()}`,
      content: "",
      timestamp: "Just now",
      isOwn: true,
      type: "gif",
      gifUrl: gifUrl,
    };
    
    setConversationMessages([...conversationMessages, newMsg]);
    setShowGifModal(false);
    setGifSearchQuery("");
    toast.success("GIF sent!");
  };

  const handleShareTrack = (album: typeof albums[0]) => {
    const newMsg = {
      id: `msg${Date.now()}`,
      content: "",
      timestamp: "Just now",
      isOwn: true,
      type: "track",
      track: {
        title: album.title,
        artist: album.artist,
        cover: album.cover,
        rating: album.averageRating,
      },
    };
    
    setConversationMessages([...conversationMessages, newMsg]);
    setShowShareTrackModal(false);
    setSearchQuery("");
    toast.success(`Shared "${album.title}"!`);
  };

  return (
    <div className="h-[calc(100vh-8rem)] animate-fade-in">
      {onBack && <BackButton onClick={onBack} label={canGoBack ? "Back" : "Back to Home"} />}
      <h1 className="text-3xl text-foreground mb-6">Messages</h1>

      <div className="grid lg:grid-cols-3 gap-4 h-full">
        {/* Conversations List */}
        <Card className="lg:col-span-1 p-4 bg-card border-border overflow-y-auto">
          <div className="space-y-2">
            {messages.map((msg) => (
              <div
                key={msg.id}
                onClick={() => setSelectedChat(msg)}
                className={`p-4 rounded-lg cursor-pointer transition ${
                  selectedChat.id === msg.id
                    ? "bg-primary/20 border border-primary/50"
                    : "hover:bg-muted"
                }`}
              >
                <div className="flex gap-3">
                  <div className="relative">
                    <Avatar className="w-12 h-12">
                      <img src={msg.userAvatar} alt={msg.userName} className="object-cover" />
                    </Avatar>
                    {msg.unread > 0 && (
                      <div className="absolute -top-1 -right-1 w-5 h-5 bg-secondary rounded-full flex items-center justify-center">
                        <span className="text-xs text-secondary-foreground">{msg.unread}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-foreground truncate">{msg.userName}</p>
                      <span className="text-xs text-muted-foreground">{msg.timestamp}</span>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{msg.lastMessage}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Chat Window */}
        <Card className="lg:col-span-2 flex flex-col bg-card border-border overflow-hidden">
          {/* Chat Header */}
          <div className="p-4 border-b border-border flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="w-10 h-10">
                <img src={selectedChat.userAvatar} alt={selectedChat.userName} className="object-cover" />
              </Avatar>
              <div>
                <p className="text-foreground">{selectedChat.userName}</p>
                <p className="text-xs text-muted-foreground">Online</p>
              </div>
            </div>
            <button className="p-2 hover:bg-muted rounded-lg transition">
              <MoreVertical className="w-5 h-5 text-muted-foreground" />
            </button>
          </div>

          {/* Messages */}
          <div ref={messagesContainerRef} className="flex-1 p-4 overflow-y-auto space-y-4">
            {conversationMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.isOwn ? "justify-end" : "justify-start"} animate-slide-in`}
              >
                <div
                  className={`max-w-[70%] ${
                    msg.type === 'gif' || msg.type === 'image' || msg.type === 'track' ? 'p-1' : 'px-4 py-3'
                  } rounded-2xl ${
                    msg.type === 'track' ? 'bg-card border border-border' :
                    msg.isOwn
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-foreground"
                  }`}
                >
                  {msg.type === 'gif' && msg.gifUrl && (
                    <img 
                      src={msg.gifUrl} 
                      alt="GIF" 
                      className="rounded-2xl max-w-full h-auto max-h-48 object-cover"
                    />
                  )}
                  {msg.type === 'image' && msg.imageUrl && (
                    <img 
                      src={msg.imageUrl} 
                      alt="Shared image" 
                      className="rounded-2xl max-w-full h-auto max-h-64 object-cover"
                    />
                  )}
                  {msg.type === 'track' && msg.track && (
                    <div className="p-3">
                      <div className="flex items-center gap-2 mb-2">
                        <Music className="w-4 h-4 text-primary" />
                        <span className="text-xs text-muted-foreground">Shared a track</span>
                      </div>
                      <div className="flex gap-3 bg-background p-3 rounded-lg">
                        <img
                          src={msg.track.cover}
                          alt={msg.track.title}
                          className="w-16 h-16 rounded object-cover"
                        />
                        <div>
                          <p className="text-sm text-foreground">{msg.track.title}</p>
                          <p className="text-xs text-muted-foreground">{msg.track.artist}</p>
                          {msg.track.rating && (
                            <Badge className="bg-primary/20 text-primary border-0 mt-1">
                              ★ {msg.track.rating}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  )}
                  {msg.content && (
                    <>
                      <p className="mb-1">{msg.content}</p>
                      <span className={`text-xs ${msg.isOwn ? "text-primary-foreground/70" : "text-muted-foreground"}`}>
                        {msg.timestamp}
                      </span>
                    </>
                  )}
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          {/* Message Input */}
          <div className="p-4 border-t border-border">
            {/* Selected Image Preview */}
            {selectedImage && (
              <div className="mb-4 relative inline-block">
                <img 
                  src={selectedImage} 
                  alt="Selected" 
                  className="max-h-32 rounded-lg border-2 border-primary"
                />
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedImage(null)}
                  className="absolute -top-2 -right-2 bg-destructive hover:bg-destructive/90 text-destructive-foreground rounded-full w-6 h-6 p-0"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            )}
            
            <div className="flex gap-2">
              <input
                type="file"
                accept="image/*"
                onChange={handleImageSelect}
                className="hidden"
                id="message-image-upload"
              />
              <Button 
                variant="outline" 
                size="icon" 
                className="border-border flex-shrink-0"
                onClick={() => document.getElementById('message-image-upload')?.click()}
                title="Add Image"
              >
                <Image className="w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                className="border-border flex-shrink-0"
                onClick={() => setShowGifModal(true)}
                title="Add GIF"
              >
                <Smile className="w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                className="border-border flex-shrink-0"
                onClick={() => setShowShareTrackModal(true)}
                title="Share Track"
              >
                <Share2 className="w-4 h-4" />
              </Button>
              <Input
                type="text"
                placeholder="Type a message..."
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                className="flex-1 bg-muted border-0 text-foreground"
                onKeyPress={(e) => {
                  if (e.key === "Enter" && (messageInput.trim() || selectedImage)) {
                    handleSendMessage();
                  }
                }}
              />
              <Button 
                className="bg-primary hover:bg-primary/90 text-primary-foreground flex-shrink-0"
                onClick={handleSendMessage}
                disabled={!messageInput.trim() && !selectedImage}
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>
      </div>

      {/* GIF Modal */}
      <Dialog open={showGifModal} onOpenChange={setShowGifModal}>
        <DialogContent className="bg-card border-border max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-foreground">Choose a GIF</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Select a GIF to send in the chat
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            {/* GIF Search */}
            <div className="flex gap-2">
              <Input
                placeholder="Search GIFs..."
                value={gifSearchQuery}
                onChange={(e) => setGifSearchQuery(e.target.value)}
                className="flex-1 bg-background border-border text-foreground placeholder:text-muted-foreground"
              />
              <Button
                variant="outline"
                className="border-border text-foreground hover:bg-muted"
              >
                <Search className="w-4 h-4" />
              </Button>
            </div>

            {/* GIF Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-h-96 overflow-y-auto nav-scroll">
              {gifSuggestions.map((gif) => (
                <div
                  key={gif.id}
                  className="relative group cursor-pointer rounded-lg overflow-hidden hover:ring-2 hover:ring-primary transition-all aspect-square"
                  onClick={() => handleSendGif(gif.url)}
                >
                  <img
                    src={gif.url}
                    alt={gif.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                    <span className="text-white opacity-0 group-hover:opacity-100 transition-opacity">
                      Send
                    </span>
                  </div>
                </div>
              ))}
            </div>

            {/* Powered by notice */}
            <p className="text-xs text-muted-foreground text-center">
              GIFs powered by GIPHY
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share Track Modal */}
      <Dialog open={showShareTrackModal} onOpenChange={setShowShareTrackModal}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-foreground">Share a Track</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Search and share a track to the chat
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            {/* Search Input */}
            <div className="flex gap-2">
              <Input
                placeholder="Search for a track or album..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-background border-border text-foreground placeholder:text-muted-foreground"
              />
              <Button
                variant="outline"
                className="border-border text-foreground hover:bg-muted"
              >
                <Search className="w-4 h-4" />
              </Button>
            </div>

            {/* Search Results */}
            <div className="space-y-2 max-h-96 overflow-y-auto nav-scroll">
              {(searchQuery ? albums.filter(
                (album) =>
                  album.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  album.artist.toLowerCase().includes(searchQuery.toLowerCase())
              ) : albums.slice(0, 5)).map((album) => (
                <div
                  key={album.id}
                  className="flex items-center gap-4 p-3 bg-background rounded-lg hover:bg-muted transition cursor-pointer group"
                >
                  <img
                    src={album.cover}
                    alt={album.title}
                    className="w-12 h-12 rounded object-cover"
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-foreground truncate">{album.title}</p>
                    <p className="text-sm text-muted-foreground truncate">{album.artist}</p>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => handleShareTrack(album)}
                    className="bg-primary hover:bg-primary/90 text-primary-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <Share2 className="w-4 h-4 mr-1" />
                    Share
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}