import { useState } from "react";
import { Plus, Check, X, Search } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { ScrollArea } from "./ui/scroll-area";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { albums } from "../lib/mockData";
import { useLists, ListAlbum } from "../lib/useUserInteractions";
import { toast } from "sonner@2.0.3";

interface AddToListDialogProps {
  isOpen: boolean;
  onClose: () => void;
  listId: string;
  listTitle: string;
}

export function AddToListDialog({ isOpen, onClose, listId, listTitle }: AddToListDialogProps) {
  const { addAlbumToList, isAlbumInList, getListAlbums } = useLists();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAlbums, setSelectedAlbums] = useState<Set<string>>(new Set());

  // Filter albums based on search query
  const filteredAlbums = albums.filter(album => {
    const query = searchQuery.toLowerCase();
    return (
      album.title.toLowerCase().includes(query) ||
      album.artist.toLowerCase().includes(query) ||
      album.genre.toLowerCase().includes(query)
    );
  });

  const handleToggleAlbum = (albumId: string) => {
    setSelectedAlbums(prev => {
      const newSet = new Set(prev);
      if (newSet.has(albumId)) {
        newSet.delete(albumId);
      } else {
        newSet.add(albumId);
      }
      return newSet;
    });
  };

  const handleAddAlbums = () => {
    let addedCount = 0;
    let skippedCount = 0;

    selectedAlbums.forEach(albumId => {
      const album = albums.find(a => a.id === albumId);
      if (album) {
        if (!isAlbumInList(listId, albumId)) {
          const listAlbum: ListAlbum = {
            id: album.id,
            title: album.title,
            artist: album.artist,
            cover: album.cover,
            year: album.year,
            genre: album.genre,
          };
          addAlbumToList(listId, listAlbum);
          addedCount++;
        } else {
          skippedCount++;
        }
      }
    });

    if (addedCount > 0) {
      toast.success(`Added ${addedCount} album${addedCount !== 1 ? 's' : ''} to ${listTitle}`, {
        description: skippedCount > 0 ? `${skippedCount} album${skippedCount !== 1 ? 's were' : ' was'} already in the list` : undefined
      });
    } else if (skippedCount > 0) {
      toast.info(`All selected albums are already in ${listTitle}`);
    }

    setSelectedAlbums(new Set());
    setSearchQuery("");
    onClose();
  };

  const handleClose = () => {
    setSelectedAlbums(new Set());
    setSearchQuery("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] p-0 gap-0">
        <DialogHeader className="p-6 pb-4 border-b border-border bg-gradient-to-br from-primary/10 to-secondary/10">
          <DialogTitle className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/20">
              <Plus className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <h2 className="text-lg text-foreground">Add Albums to List</h2>
              <p className="text-sm text-muted-foreground mt-0.5">
                {listTitle}
              </p>
            </div>
          </DialogTitle>
          <DialogDescription className="sr-only">
            Select albums to add to {listTitle}
          </DialogDescription>
        </DialogHeader>

        <div className="p-6 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search albums, artists, or genres..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Selected Count */}
          {selectedAlbums.size > 0 && (
            <div className="flex items-center justify-between p-3 bg-primary/10 border border-primary/20 rounded-lg">
              <p className="text-sm text-foreground">
                {selectedAlbums.size} album{selectedAlbums.size !== 1 ? 's' : ''} selected
              </p>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setSelectedAlbums(new Set())}
                className="text-xs hover:bg-primary/20"
              >
                Clear
              </Button>
            </div>
          )}

          {/* Albums Grid */}
          <ScrollArea className="h-[50vh]">
            <div className="grid sm:grid-cols-2 gap-3 pr-4">
              {filteredAlbums.map((album) => {
                const isSelected = selectedAlbums.has(album.id);
                const isInList = isAlbumInList(listId, album.id);

                return (
                  <Card
                    key={album.id}
                    onClick={() => !isInList && handleToggleAlbum(album.id)}
                    className={`p-3 cursor-pointer transition-all ${
                      isInList
                        ? "opacity-50 cursor-not-allowed bg-muted border-muted"
                        : isSelected
                        ? "bg-primary/10 border-primary shadow-soft"
                        : "bg-card border-border hover:border-primary/50"
                    }`}
                  >
                    <div className="flex gap-3">
                      {/* Album Cover */}
                      <div className="relative flex-shrink-0">
                        <img
                          src={album.cover}
                          alt={album.title}
                          className="w-16 h-16 rounded object-cover"
                        />
                        {isInList && (
                          <div className="absolute inset-0 bg-black/60 rounded flex items-center justify-center">
                            <Check className="w-6 h-6 text-white" />
                          </div>
                        )}
                        {isSelected && !isInList && (
                          <div className="absolute inset-0 bg-primary/60 rounded flex items-center justify-center">
                            <Check className="w-6 h-6 text-white" />
                          </div>
                        )}
                      </div>

                      {/* Album Info */}
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm text-foreground truncate mb-0.5">
                          {album.title}
                        </h4>
                        <p className="text-xs text-muted-foreground truncate mb-1">
                          {album.artist}
                        </p>
                        <div className="flex items-center gap-2">
                          {album.year && (
                            <Badge variant="outline" className="text-xs px-1.5 py-0">
                              {album.year}
                            </Badge>
                          )}
                          {album.genre && (
                            <Badge className="bg-primary/15 text-primary border-0 text-xs px-1.5 py-0">
                              {album.genre}
                            </Badge>
                          )}
                        </div>
                        {isInList && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Already in list
                          </p>
                        )}
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>

            {filteredAlbums.length === 0 && (
              <div className="text-center py-12">
                <p className="text-muted-foreground">
                  {searchQuery ? "No albums found matching your search" : "No albums available"}
                </p>
              </div>
            )}
          </ScrollArea>
        </div>

        {/* Footer */}
        <div className="p-6 pt-4 border-t border-border bg-muted/20 flex gap-3">
          <Button
            variant="outline"
            onClick={handleClose}
            className="flex-1"
          >
            Cancel
          </Button>
          <Button
            onClick={handleAddAlbums}
            disabled={selectedAlbums.size === 0}
            className="flex-1 bg-primary hover:bg-primary/90"
          >
            Add {selectedAlbums.size > 0 && `(${selectedAlbums.size})`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
