import { useState } from "react";
import { ArrowLeft, Plus, Trash2, Music, Calendar } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { myLists, albums as allAlbums } from "../lib/mockData";
import { useLists } from "../lib/useUserInteractions";
import { AddToListDialog } from "./AddToListDialog";
import { toast } from "sonner@2.0.3";
import { BackButton } from "./BackButton";

interface CollectionDetailPageProps {
  listId: string;
  onNavigate?: (page: string) => void;
  onOpenAlbum?: () => void;
  onBack?: () => void;
  canGoBack?: boolean;
}

export function CollectionDetailPage({ listId, onNavigate, onOpenAlbum, onBack, canGoBack }: CollectionDetailPageProps) {
  const [addDialogOpen, setAddDialogOpen] = useState(false);
  const { getListAlbums, removeAlbumFromList, userListsMetadata } = useLists();
  
  // Find the list from mock data or user-created lists
  const mockList = myLists.find(l => l.id === listId);
  const userList = userListsMetadata[listId];
  const list = userList || mockList;
  
  if (!list) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">List not found</p>
      </div>
    );
  }

  // Get user-added albums from localStorage
  const userAddedAlbums = getListAlbums(listId);
  
  // Get default albums for this list (based on coverImages)
  const defaultAlbumIdsWithDuplicates = list.coverImages.map(cover => {
    const album = allAlbums.find(a => a.cover === cover);
    return album?.id;
  }).filter(Boolean) as string[];
  
  // Remove duplicates using Set
  const defaultAlbumIds = Array.from(new Set(defaultAlbumIdsWithDuplicates));
  
  const defaultAlbums = defaultAlbumIds.map(id => {
    const album = allAlbums.find(a => a.id === id);
    return album ? {
      id: album.id,
      title: album.title,
      artist: album.artist,
      cover: album.cover,
      year: album.year,
      genre: album.genre,
    } : null;
  }).filter(Boolean);

  // For user-created lists, use the albums stored in the list
  const isUserList = !!userList;
  let allListAlbums;
  
  if (isUserList && userList.albums && userList.albums.length > 0) {
    // User-created list: use albums from metadata
    allListAlbums = userList.albums;
  } else {
    // Mock list: combine default albums with user-added albums (avoid duplicates)
    allListAlbums = [
      ...defaultAlbums,
      ...userAddedAlbums.filter(ua => !defaultAlbumIds.includes(ua.id))
    ];
  }

  const totalAlbumCount = allListAlbums.length;

  const handleRemoveAlbum = (albumId: string, albumTitle: string) => {
    // For user-created lists, allow removing any album
    if (!isUserList) {
      // Only allow removing user-added albums from mock lists, not default ones
      if (defaultAlbumIds.includes(albumId)) {
        toast.error("Cannot remove default albums from this list");
        return;
      }
    }

    removeAlbumFromList(listId, albumId);
    toast.success(`Removed "${albumTitle}" from ${list.title}`);
  };

  return (
    <div className="min-h-screen pb-8">
      {/* Header */}
      <div className="mb-6 space-y-4">
        <div className="flex items-center gap-4">
          <BackButton onClick={onBack || (() => onNavigate?.("your-space-lists"))} label={canGoBack ? "Back" : "Back to My Lists"} />
          <div className="flex-1">
            <h1 className="text-2xl md:text-3xl text-foreground">{list.title}</h1>
            {list.description && (
              <p className="text-sm text-muted-foreground mt-1">{list.description}</p>
            )}
          </div>
          <Button
            onClick={() => setAddDialogOpen(true)}
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Albums
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          <Card key="albums-stat" className="p-4 bg-card border-border text-center">
            <p className="text-2xl text-primary mb-1">{totalAlbumCount}</p>
            <p className="text-sm text-muted-foreground">Albums</p>
          </Card>
          {!isUserList && (
            <Card key="added-by-you-stat" className="p-4 bg-card border-border text-center">
              <p className="text-2xl text-secondary mb-1">{userAddedAlbums.length}</p>
              <p className="text-sm text-muted-foreground">Added by You</p>
            </Card>
          )}
          <Card key="artists-stat" className={`p-4 bg-card border-border text-center ${isUserList ? 'col-span-1' : 'col-span-2 sm:col-span-1'}`}>
            <p className="text-2xl text-accent mb-1">
              {new Set(allListAlbums.map(a => a.artist)).size}
            </p>
            <p className="text-sm text-muted-foreground">Artists</p>
          </Card>
        </div>
      </div>

      {/* Albums Grid */}
      {allListAlbums.length > 0 ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {allListAlbums.map((album) => {
            const isUserAdded = !defaultAlbumIds.includes(album.id);
            const canRemove = isUserList || isUserAdded;
            
            return (
              <Card
                key={album.id}
                className="p-4 bg-card border-border hover:border-primary/50 transition-all shadow-soft hover:shadow-medium group"
              >
                {/* Album Cover */}
                <div 
                  className="relative mb-3 cursor-pointer"
                  onClick={() => onOpenAlbum?.()}
                >
                  <img
                    src={album.cover}
                    alt={album.title}
                    className="w-full aspect-square rounded-lg object-cover group-hover:scale-105 transition-transform"
                  />
                  {!isUserList && isUserAdded && (
                    <Badge className="absolute top-2 right-2 bg-secondary/90 text-white border-0 text-xs">
                      Added
                    </Badge>
                  )}
                </div>

                {/* Album Info */}
                <div className="space-y-2">
                  <div>
                    <h3 className="text-foreground group-hover:text-primary transition line-clamp-1">
                      {album.title}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-1">
                      {album.artist}
                    </p>
                  </div>

                  {/* Metadata */}
                  <div className="flex items-center gap-2 flex-wrap">
                    {album.year && (
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Calendar className="w-3 h-3" />
                        {album.year}
                      </div>
                    )}
                    {album.genre && (
                      <Badge className="bg-primary/15 text-primary border-0 text-xs px-2 py-0">
                        {album.genre}
                      </Badge>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2 pt-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => onOpenAlbum?.()}
                      className="flex-1 border-border hover:border-primary hover:text-primary"
                    >
                      <Music className="w-3 h-3 mr-1" />
                      View
                    </Button>
                    {canRemove && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleRemoveAlbum(album.id, album.title)}
                        className="text-destructive hover:text-destructive hover:bg-destructive/10"
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card className="p-12 bg-card border-border text-center">
          <div className="max-w-md mx-auto space-y-4">
            <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
              <Music className="w-8 h-8 text-primary" />
            </div>
            <div>
              <h3 className="text-lg text-foreground mb-2">No Albums Yet</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Start building your collection by adding albums
              </p>
              <Button
                onClick={() => setAddDialogOpen(true)}
                className="bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Your First Album
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Add to List Dialog */}
      <AddToListDialog
        isOpen={addDialogOpen}
        onClose={() => setAddDialogOpen(false)}
        listId={listId}
        listTitle={list.title}
      />
    </div>
  );
}
