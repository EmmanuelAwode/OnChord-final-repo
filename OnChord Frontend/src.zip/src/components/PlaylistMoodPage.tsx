import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Smile, Coffee, Dumbbell, PartyPopper, TrendingUp, Flame, Zap, Brain } from "lucide-react";
import { moodData, listeningStats } from "../lib/mockData";

const moodIcons = {
  Aggressive: Flame,
  Chill: Smile,
  Hype: Zap,
  Conscious: Brain,
  Study: Coffee,
  Gym: Dumbbell,
  Party: PartyPopper,
};

export function PlaylistMoodPage() {
  const dominantMood = moodData[0];
  const DominantIcon = moodIcons[dominantMood.mood as keyof typeof moodIcons] || Smile;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl text-foreground">Your Mood Analysis</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          AI-powered mood classification based on your listening habits
        </p>
      </div>

      {/* Dominant Mood Card */}
      <Card className="p-8 bg-gradient-to-br from-destructive/20 to-chart-5/20 border-destructive/30">
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="p-6 rounded-full" style={{ backgroundColor: `${dominantMood.color}30` }}>
              <DominantIcon className="w-12 h-12" style={{ color: dominantMood.color }} />
            </div>
          </div>
          <div>
            <p className="text-muted-foreground mb-1">This month, you've been in a</p>
            <h2 className="text-4xl mb-2" style={{ color: dominantMood.color }}>{dominantMood.mood} Vibe</h2>
            <p className="text-foreground">
              {dominantMood.percentage}% of your listening time
            </p>
          </div>
        </div>
      </Card>

      {/* Mood Breakdown */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-foreground mb-6">Mood Breakdown</h3>
        <div className="space-y-6">
          {moodData.map((mood) => {
            const Icon = moodIcons[mood.mood as keyof typeof moodIcons];
            return (
              <div key={mood.mood} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="p-2 rounded-lg"
                      style={{ backgroundColor: `${mood.color}20` }}
                    >
                      <Icon className="w-5 h-5" style={{ color: mood.color }} />
                    </div>
                    <span className="text-foreground">{mood.mood}</span>
                  </div>
                  <span className="text-foreground">{mood.percentage}%</span>
                </div>
                <Progress
                  value={mood.percentage}
                  className="h-2"
                  style={
                    {
                      "--progress-background": mood.color,
                    } as React.CSSProperties
                  }
                />
              </div>
            );
          })}
        </div>
      </Card>

      {/* Mood Badges */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-foreground mb-4">Your Mood Tags</h3>
        <div className="flex flex-wrap gap-3">
          <Badge className="bg-destructive/20 text-destructive border-0 px-4 py-2">
            🔥 Aggressive Bars
          </Badge>
          <Badge className="bg-primary/20 text-primary border-0 px-4 py-2">
            😌 Chill Vibes
          </Badge>
          <Badge className="bg-chart-5/20 text-chart-5 border-0 px-4 py-2">
            ⚡ Hype Energy
          </Badge>
          <Badge className="bg-secondary/20 text-secondary border-0 px-4 py-2">
            🧠 Conscious Listener
          </Badge>
        </div>
      </Card>

      {/* Insights */}
      <div className="grid md:grid-cols-2 gap-4">
        <Card className="p-6 bg-card border-border">
          <div className="flex gap-4">
            <div className="bg-destructive/20 p-3 rounded-lg h-fit">
              <TrendingUp className="w-6 h-6 text-destructive" />
            </div>
            <div>
              <h4 className="text-foreground mb-2">Mood Trend</h4>
              <p className="text-sm text-muted-foreground">
                Your Aggressive mood has increased by 15% this month. You're vibing with harder-hitting tracks!
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6 bg-card border-border">
          <div className="flex gap-4">
            <div className="bg-chart-5/20 p-3 rounded-lg h-fit">
              <Zap className="w-6 h-6 text-chart-5" />
            </div>
            <div>
              <h4 className="text-foreground mb-2">Peak Hype Time</h4>
              <p className="text-sm text-muted-foreground">
                You listen to Hype playlists most between 6-10 PM. Perfect for evening energy boosts!
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* How It Works */}
      <Card className="p-6 bg-card border-border">
        <h3 className="text-foreground mb-3">How Mood Classification Works</h3>
        <p className="text-muted-foreground text-sm mb-4">
          Our AI analyzes various factors in your listening patterns:
        </p>
        <ul className="space-y-2 text-sm text-muted-foreground">
          <li className="flex items-start gap-2">
            <span className="text-primary">•</span>
            <span>Tempo and energy levels of tracks you listen to</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-primary">•</span>
            <span>Time of day and listening duration</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-primary">•</span>
            <span>Playlist names and genres you engage with</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-primary">•</span>
            <span>Audio features like valence, danceability, and acousticness</span>
          </li>
        </ul>
      </Card>
    </div>
  );
}