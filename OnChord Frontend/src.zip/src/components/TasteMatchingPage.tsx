import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar } from "./ui/avatar";
import { Users, Sparkles, UserPlus, UserCheck } from "lucide-react";
import { tasteMatches } from "../lib/mockData";
import { useFollowing } from "../lib/useUserInteractions";
import { toast } from "sonner@2.0.3";

export function TasteMatchingPage() {
  const { toggleFollow, isFollowing } = useFollowing();

  const handleConnectClick = (userId: string, userName: string) => {
    const wasFollowing = isFollowing(userId);
    toggleFollow(userId);
    
    if (wasFollowing) {
      toast.success(`Disconnected from ${userName}`);
    } else {
      toast.success(`Connected with ${userName}!`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <div className="flex justify-center mb-4">
          <div className="bg-primary/10 p-4 rounded-full">
            <Sparkles className="w-8 h-8 text-primary" />
          </div>
        </div>
        <h1 className="text-3xl text-foreground">Find Your Taste Matches</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Discover people with similar music taste. Our AI analyzes your listening history to find the perfect matches.
        </p>
      </div>

      {/* Taste Match Cards */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {tasteMatches.map((match) => (
          <Card
            key={match.id}
            className="p-6 bg-card border-border hover:border-primary/50 transition"
          >
            {/* Compatibility Header */}
            <div className="text-center mb-4">
              <div
                className="w-24 h-24 rounded-full mx-auto mb-3 flex items-center justify-center"
                style={{
                  background: `conic-gradient(#A78BFA ${match.compatibility * 3.6}deg, #3B4252 0deg)`,
                }}
              >
                <div className="w-20 h-20 rounded-full bg-card flex items-center justify-center">
                  <div>
                    <p className="text-2xl text-primary">{match.compatibility}%</p>
                    <p className="text-xs text-muted-foreground">Match</p>
                  </div>
                </div>
              </div>
            </div>

            {/* User Info */}
            <div className="flex items-center gap-3 mb-4">
              <Avatar className="w-12 h-12">
                <img src={match.avatar} alt={match.name} className="object-cover" />
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-foreground truncate">{match.name}</p>
                <p className="text-sm text-muted-foreground truncate">{match.username}</p>
              </div>
            </div>

            {/* Common Artists */}
            <div className="mb-4">
              <p className="text-sm text-muted-foreground mb-2">Common Artists</p>
              <div className="flex flex-wrap gap-2">
                {match.commonArtists.map((artist) => (
                  <Badge
                    key={artist}
                    variant="secondary"
                    className="bg-secondary/20 text-secondary border-0"
                  >
                    {artist}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Mutual Friends */}
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
              <Users className="w-4 h-4" />
              <span>{match.mutualFriends} mutual friends</span>
            </div>

            {/* Connect Button */}
            <Button 
              className={`w-full transition-all ${
                isFollowing(match.userId)
                  ? "bg-secondary hover:bg-secondary/90 text-secondary-foreground"
                  : "bg-primary hover:bg-primary/90 text-primary-foreground"
              }`}
              onClick={() => handleConnectClick(match.userId, match.name)}
            >
              {isFollowing(match.userId) ? (
                <>
                  <UserCheck className="w-4 h-4 mr-2" />
                  Connected
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Connect
                </>
              )}
            </Button>
          </Card>
        ))}
      </div>

      {/* Info Card */}
      <Card className="p-6 bg-gradient-to-br from-primary/10 to-secondary/10 border-primary/30">
        <div className="flex gap-4 items-start">
          <div className="bg-primary/20 p-3 rounded-lg">
            <Sparkles className="w-6 h-6 text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="text-foreground mb-2">How It Works</h3>
            <p className="text-muted-foreground text-sm mb-3">
              Our machine learning algorithm analyzes your listening patterns, favorite genres, and review history 
              to find users with similar taste. Higher compatibility means more shared musical preferences!
            </p>
            <p className="text-xs text-muted-foreground">
              Note: OnChord is focused on friendship and music discovery, not dating.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}