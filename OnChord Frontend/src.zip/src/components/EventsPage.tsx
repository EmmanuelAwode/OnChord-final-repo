import { useState } from "react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Calendar, MapPin, ExternalLink, Search, Music } from "lucide-react";
import { upcomingEvents } from "../lib/mockData";
import { EmptyState } from "./EmptyState";
import { EventModal } from "./EventModal";
import { SetReminderDialog } from "./SetReminderDialog";
import { BackButton } from "./BackButton";

interface EventsPageProps {
  onNavigate?: (page: string, eventId?: string) => void;
  onBack?: () => void;
  canGoBack?: boolean;
}

export function EventsPage({ onNavigate, onBack, canGoBack }: EventsPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const [eventModalOpen, setEventModalOpen] = useState(false);
  const [reminderDialogOpen, setReminderDialogOpen] = useState(false);
  const [reminderEventData, setReminderEventData] = useState<any>(null);

  const filteredEvents = upcomingEvents.filter(
    (event) =>
      event.artistName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.venue.toLowerCase().includes(searchQuery.toLowerCase()) ||
      event.city.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Back Button */}
      {onBack && (
        <BackButton onClick={onBack} label={canGoBack ? "Back" : "Back to Home"} />
      )}

      {/* Header */}
      <div>
        <h1 className="mb-2">Concerts & Events</h1>
        <p className="text-muted-foreground">
          Find live shows from your favorite hip-hop artists
        </p>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Search by artist, venue, or city..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-12 bg-card border-border"
        />
      </div>

      {/* Events Grid */}
      {filteredEvents.length > 0 ? (
        <div className="grid gap-4">
          {filteredEvents.map((event) => (
            <Card
              key={event.id}
              className="overflow-hidden bg-card border-border hover:border-primary transition-all group cursor-pointer"
              onClick={() => {
                setSelectedEvent(event);
                setEventModalOpen(true);
              }}
            >
              <div className="flex flex-col md:flex-row">
                {/* Event Image */}
                <div className="relative w-full md:w-48 h-48 md:h-auto overflow-hidden flex-shrink-0">
                  <img
                    src={event.thumbnail}
                    alt={event.artistName}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-4 left-4">
                    <Badge className="bg-primary text-primary-foreground">
                      Live
                    </Badge>
                  </div>
                </div>

                {/* Event Details */}
                <div className="flex-1 p-4 md:p-6">
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="text-foreground mb-2">{event.artistName}</h3>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="w-4 h-4 text-primary" />
                          {event.date}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="w-4 h-4 text-secondary" />
                          {event.venue}, {event.city}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col gap-2 md:items-end">
                      <Button
                        size="sm"
                        className="bg-primary hover:bg-primary/90 text-primary-foreground"
                        onClick={(e) => {
                          e.stopPropagation();
                          window.open('https://www.ticketmaster.com', '_blank');
                        }}
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Get Tickets
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        className="border-secondary text-secondary hover:bg-secondary hover:text-secondary-foreground"
                        onClick={(e) => {
                          e.stopPropagation();
                          setReminderEventData(event);
                          setReminderDialogOpen(true);
                        }}
                      >
                        <Calendar className="w-4 h-4 mr-2" />
                        Remind Me
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Music}
          title="No Events Found"
          description={
            searchQuery
              ? `No events found for "${searchQuery}". Try different keywords.`
              : "No upcoming events at the moment. Check back soon!"
          }
        />
      )}

      {/* Powered by Ticketmaster */}
      <div className="text-center pt-8">
        <p className="text-xs text-muted-foreground">
          Event data powered by Ticketmaster API
        </p>
      </div>

      {/* Event Modal */}
      <EventModal
        event={selectedEvent}
        isOpen={eventModalOpen}
        onClose={() => {
          setEventModalOpen(false);
          setSelectedEvent(null);
        }}
      />

      {/* Set Reminder Dialog */}
      <SetReminderDialog
        isOpen={reminderDialogOpen}
        onClose={() => {
          setReminderDialogOpen(false);
          setReminderEventData(null);
        }}
        defaultData={reminderEventData ? {
          type: 'event',
          title: reminderEventData.artistName,
          description: `Live at ${reminderEventData.venue}`,
          date: reminderEventData.dateISO || new Date(reminderEventData.date).toISOString().split('T')[0],
          thumbnail: reminderEventData.thumbnail,
          location: `${reminderEventData.venue}, ${reminderEventData.city}`,
          eventId: reminderEventData.id
        } : undefined}
      />
    </div>
  );
}